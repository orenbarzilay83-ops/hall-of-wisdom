/**
 * kashf-canonical-method-registry.js
 *
 * P0 source-of-truth for Kashf source-specific intents and their ONE
 * canonical operational method.
 *
 * IMPORTANT:
 * - Hall of Wisdom generic `intentId` lives elsewhere (prediction,
 *   timingRequest, ...). This file uses `kashfIntentId` only.
 * - `runtimeAllowed:false` is a hard stop. Callers must never silently fall
 *   back to topic-level execution.
 * - `kashfRuntimeStatus` describes source/method readiness; `executorStatus`
 *   independently describes whether the new canonical runtime can execute it.
 * - Educational / external methods may remain available to the knowledge
 *   layer but must never feed a live Kashf verdict.
 */

export const KASHF_RUNTIME_STATUSES = Object.freeze([
  'ready',
  'repair-required',
  'blocked-by-source',
  'educational-only',
  'unsupported',
]);

export const KASHF_METHOD_ROLES = Object.freeze([
  'canonical-operational',
  'supporting-condition',
  'educational-only',
  'external-tradition',
  'unresolved',
]);

export const KASHF_EXECUTOR_STATUSES = Object.freeze([
  'ready',
  'pending',
  'not-applicable',
]);

const method = ({
  kashfMethodId,
  kashfIntentId,
  topicId = null,
  sourcePages = [],
  sourceLayer = 'body',
  attributedSourceBook = 'Kashf',
  sourceConfidence = 'confirmed',
  methodRole = 'canonical-operational',
  kashfRuntimeStatus,
  runtimeAllowed,
  executionKind = null,
  executorStatus = executionKind ? 'pending' : 'not-applicable',
  legacyTopicId = null,
  legacyFormulaSlot = null,
  notes = null,
}) => Object.freeze({
  kashfMethodId,
  kashfIntentId,
  topicId,
  methodRole,
  kashfRuntimeStatus,
  runtimeAllowed: runtimeAllowed === true,
  sourceVolume: 'kashf',
  sourcePages: Object.freeze([...sourcePages]),
  sourceLayer,
  attributedSourceBook,
  sourceConfidence,
  executionKind,
  executorStatus,
  legacyTopicId,
  legacyFormulaSlot,
  notes,
});

/**
 * Canonical-method registry.
 *
 * A method may be source-ready while its new canonical executor is still
 * pending. Only records with runtimeAllowed=true AND executorStatus=ready may
 * execute. This prevents source confidence from being confused with code
 * readiness.
 */
export const KASHF_CANONICAL_METHODS = Object.freeze({
  // ── READY + EXECUTOR READY pilot slice --------------------------------
  'completion.p173.fireRows15910': method({
    kashfMethodId: 'completion.p173.fireRows15910',
    kashfIntentId: 'completion.willComplete',
    topicId: 'completion',
    sourcePages: [173],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'formula',
    executorStatus: 'ready',
    legacyTopicId: 'completion',
    legacyFormulaSlot: 'primaryFormula',
    notes: 'Canonical p173 method. Legacy alt 1+16 is not part of this verdict.',
  }),

  'relocation.p183.h4h15': method({
    kashfMethodId: 'relocation.p183.h4h15',
    kashfIntentId: 'relocation.placeToPlace',
    topicId: 'relocation',
    sourcePages: [183],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'formula',
    executorStatus: 'ready',
    legacyTopicId: 'relocation',
    legacyFormulaSlot: 'primaryFormula',
    notes: 'Exact p183 destination-quality method only: derive H4+H15 and judge the resulting figure by benefic/malefic/mixed. It does not execute the legacy H1+H15 alt formula, the H1/H2 stay-or-move rule, the H1/H4 vs H7/H10 place-quality rule, or the two-city strength comparison.',
  }),

  'siblings.p182.h1h3': method({
    kashfMethodId: 'siblings.p182.h1h3',
    kashfIntentId: 'siblings.relationship',
    topicId: 'siblings',
    sourcePages: [182],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'formula',
    executorStatus: 'ready',
    legacyTopicId: 'siblings',
    legacyFormulaSlot: 'primaryFormula',
  }),

  'travel.p238.assemble1359': method({
    kashfMethodId: 'travel.p238.assemble1359',
    kashfIntentId: 'travel.success',
    topicId: 'travel',
    sourcePages: [238],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'formula',
    executorStatus: 'ready',
    legacyTopicId: 'travel',
    legacyFormulaSlot: 'primaryFormula',
  }),

  // ── SOURCE READY; CANONICAL EXECUTOR PENDING ---------------------------
  'dhamir.p159.subjectByH6Recurrence': method({
    kashfMethodId: 'dhamir.p159.subjectByH6Recurrence',
    kashfIntentId: 'dhamir.identifyQuestionSubject',
    topicId: 'generalReading',
    sourcePages: [159],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Dedicated p159 rule only for the exact intent “whom/what is the querent asking about?”. It reads H6 and the recurrence of the same figure in another topical house. It is not a generic hidden-thought/intent method and must not replace the selected Dhamir route for “what is the person thinking?”. Multiple recurrences remain ambiguous because the source gives no precedence.',
  }),

  'general.p174.h1h2h4h7h10h15': method({
    kashfMethodId: 'general.p174.h1h2h4h7h10h15',
    kashfIntentId: 'general.state',
    topicId: 'generalReading',
    sourcePages: [174],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'generalReading',
    notes: 'Canonical p174 general-state executor is wired. It reads only H1,H2,H4,H7,H10,H15 separately according to their explicit v57 roles. It does not execute the broad legacy generalReading bundle, does not average or majority-vote the six houses, and does not collapse them into one yes/no verdict. Each house exposes its figure and canonical fortune class for a bounded general-state reading.',
  }),

  'messenger.p176.recast14511': method({
    kashfMethodId: 'messenger.p176.recast14511',
    kashfIntentId: 'messenger.outcome',
    topicId: 'siblings',
    sourcePages: [176],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'recast-board',
    executorStatus: 'pending',
    notes: 'Printed p176 asks about the outcome of messengers and whether the request is fulfilled. Current q-message/q-news-arrive labels instead ask whether a letter/news arrives; that intent is not identical. Source p176 requires a separate derived board: copy H1,H4,H5,H11 from the source board as the four new mothers, complete a NEW board, then judge derived-board H5 and the angles. The source board must remain immutable. Repair the route intent before any executor and Golden Tests.',
  }),

  'clothing.p264-265.luck': method({
    kashfMethodId: 'clothing.p264-265.luck',
    kashfIntentId: 'clothing.luck',
    topicId: 'generalReading',
    sourcePages: [264, 265],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'generalReading',
    notes: 'Canonical clothing-luck executor is wired from v57 pp264-265 using only the explicit fortune clauses: H5+H11 both pure benefic => luck in clothing; both pure malefic => no luck in clothing; pure malefic H10 separately indicates no luck in royal clothing/honor from superiors. Mixed/split testimony remains unresolved. The legacy helper is not reused because it collapses mixed figures and invents a partial branch. Fixed/mutable persistence and clothing-color subrules are excluded from this luck verdict.',
  }),

  // ── HOUSE 1 pp172-177 exact-intent boundaries ----------------------
  'matter.p172.locationH2H16': method({
    kashfMethodId: 'matter.p172.locationH2H16',
    kashfIntentId: 'matter.locateMatterAndEarningsHouse',
    topicId: 'generalReading',
    sourcePages: [172],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Source says combine H2+H16 to identify the house of the querent’s matter and earnings/acquisition, but this passage does not define the mapping from the resulting figure to a target house. Do not narrow the intent to money and do not infer the missing mapping from another table.',
  }),

  'friend.p173.uniqueTariqBalance': method({
    kashfMethodId: 'friend.p173.uniqueTariqBalance',
    kashfIntentId: 'friend.loveOrDirectedElsewhere',
    topicId: 'friendsHope',
    sourcePages: [173],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Specific p173 friend-love method only: after completing through H15, a unique Tariq/Derekh in the balance indicates the friend loves the subject; a matching Tariq in H7 indicates direction to another. It is not a generic love method and has no approved Question Bank route/executor.',
  }),

  'hope.p174.h5h11ThroughH1': method({
    kashfMethodId: 'hope.p174.h5h11ThroughH1',
    kashfIntentId: 'hope.fulfillmentP174',
    topicId: 'friendsHope',
    sourcePages: [174],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Source requires TWO intermediate figures: H5 combined with H1, and H11 combined with H1; only then combine those intermediates and judge benefic/malefic plus internal/external. Current v57 collapses this procedure, so it cannot run and must not be merged with the separate p267 hope route.',
  }),

  'authority.p175-176.needBeforeRulerChain': method({
    kashfMethodId: 'authority.p175-176.needBeforeRulerChain',
    kashfIntentId: 'authority.needBeforeRuler',
    topicId: 'authorityState',
    sourcePages: [175, 176],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'source-rule-set',
    executorStatus: 'pending',
    notes: 'One source framework for a need before a ruler: H1/H10 element+quality, H11 relative to H10, H2 money/goods branches, then H12/H6 and later houses. Current v57 still mistranslates the fixed-H2 goods/prosperity branch. Do not split these subclauses into universal background rules or invent an air/fire result.',
  }),

  'request.p176.h1h2GateThenH1H4': method({
    kashfMethodId: 'request.p176.h1h2GateThenH1H4',
    kashfIntentId: 'request.fulfillmentAndEnd',
    topicId: 'completion',
    sourcePages: [176],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Exact p176 request method: H1/H2 are a gate; if either is malefic the source says leave the request. Otherwise derive H1+H4 and judge benefic/malefic/mixed. Source is clear, but no canonical executor or approved public route is enabled yet.',
  }),

  'intent.p176.h7h10': method({
    kashfMethodId: 'intent.p176.h7h10',
    kashfIntentId: 'person.intent',
    topicId: 'generalReading',
    sourcePages: [176],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Exact p176 person-intent method: derive H7+H10; benefic means good intent and malefic means bad/malefic intent. This is not Gate-4 Dhamir and must not auto-run with hidden-thought methods.',
  }),

  'meeting.p176.hopeHouseH1H13': method({
    kashfMethodId: 'meeting.p176.hopeHouseH1H13',
    kashfIntentId: 'meeting.requestedPerson',
    topicId: 'generalReading',
    sourcePages: [176],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-rule',
    executorStatus: 'pending',
    notes: 'Exact p176 meeting rule only: the source requires the hope-house indication in both H1 and H13; otherwise no meeting. Runtime stays disabled until “hope house” is tied to a certified operational representation for this rule.',
  }),

  'person.p177.relativeThirteenth': method({
    kashfMethodId: 'person.p177.relativeThirteenth',
    kashfIntentId: 'person.relativeThirteenthReading',
    topicId: 'generalReading',
    sourcePages: [177],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'recursive-house-procedure',
    executorStatus: 'pending',
    notes: 'Reference-only p177 recursive procedure. Branch order is still corrupted in v57, source tokens معموم and ولا يحصل معارك remain unresolved, and a canonical per-house relative-thirteenth mapping is not certified. Do not infer the recursive mapping or normalize the difficult tokens.',
  }),

  'matter.p172.h17_h1011_thenCombine': method({
    kashfMethodId: 'matter.p172.h17_h1011_thenCombine',
    kashfIntentId: 'matter.outcome',
    topicId: 'generalReading',
    sourcePages: [172],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p172 matter-outcome executor is wired only after a complete 16-position board exists: the printed source first requires completing the line through H16, then combine H1+H7, combine H10+H11, and combine those two generated figures. The final figure alone is the source result for good/bad. Pure benefic => good, pure malefic => bad, and mixed remains mixed/unresolved rather than being collapsed. Distinct from completion p173.',
  }),

  'joy.p196.recast14511': method({
    kashfMethodId: 'joy.p196.recast14511',
    kashfIntentId: 'joy.occurrence',
    topicId: 'completion',
    sourcePages: [196],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'recast-board',
    executorStatus: 'pending',
    notes: 'v57 p196 is the illness/lost-item/animals chapter and does not contain the 1,4,5,11 joy/event recast. The known celebrations helper is sourced from an external PDF, not Kashf. Do not execute or backfill it as a Kashf method until a real v57 source method is identified.',
  }),

  'relocation.p183.currentVsNewPlace': method({
    kashfMethodId: 'relocation.p183.currentVsNewPlace',
    kashfIntentId: 'relocation.isThisPlaceGood',
    topicId: 'relocation',
    sourcePages: [183],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p183 place/move executor is wired. H1+H4 both pure benefic => good residence in the current place; H7+H10 both pure benefic => good move/relocation. The source does not say that failure of either pair proves the opposite, and it does not compare which option is better when both pairs qualify. Mixed figures are not promoted to pure benefic.',
  }),

  'relocation.p183.stayMoveH1H2': method({
    kashfMethodId: 'relocation.p183.stayMoveH1H2',
    kashfIntentId: 'relocation.stayOrMove',
    topicId: 'relocation',
    sourcePages: [178, 183],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'relocation',
    notes: 'Canonical H1/H2 stay-or-move executor is wired from the repeated v57 rule on pp178 and 183. H1 pure benefic + H2 pure malefic => the current place is better / stay. H1 pure malefic + H2 pure benefic => the reverse / moving away is better. Same-class, mixed or unknown testimony remains unresolved; no broad relocation helper is executed.',
  }),

  'illness.p196.outcomeH15': method({
    kashfMethodId: 'illness.p196.outcomeH15',
    kashfIntentId: 'illness.recovery',
    topicId: 'illness',
    sourcePages: [196],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'illness',
    notes: 'Canonical p196 H15 executor is wired. Pure benefic => recovery; pure malefic => illness is prolonged. A malefic H15 is NOT promoted to a death/no-recovery verdict, because the source does not say that here. Mixed remains unresolved. Only H15 is executed for this intent; H1 recurrence, sensory signs, p197 humors/body-location and the broader illness bundle stay outside the verdict.',
  }),

  'illness.p196.h1RecurrenceDurationRisk': method({
    kashfMethodId: 'illness.p196.h1RecurrenceDurationRisk',
    kashfIntentId: 'illness.durationRisk',
    topicId: 'illness',
    sourcePages: [196],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p196 opening gives a separate recurrence rule: the H1 figure occurring in H6 indicates prolonged illness; the H1 figure occurring in H8 indicates prolonged illness plus fear/danger. This is not the H15 recovery route and does not provide a numeric duration. No UI runtime is enabled until the recurrence wording and client-safe risk phrasing are separately certified.',
  }),

  'illness.p196.sensorySignsH6H8': method({
    kashfMethodId: 'illness.p196.sensorySignsH6H8',
    kashfIntentId: 'illness.sensorySigns',
    topicId: 'illness',
    sourcePages: [196],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p196 sensory branches are separate from recovery: the Ahyan example in H8 indicates blindness, Ahyan in H6 indicates dark/dim vision, and Saturn/Jupiter figures in H6 or H8 indicate heaviness of hearing. Preserve as source knowledge only; do not use these signs as medical diagnosis and do not mix them into q-illness-heal.',
  }),

  'illness.bodyPart.h6Figure': method({
    kashfMethodId: 'illness.bodyPart.h6Figure',
    kashfIntentId: 'illness.bodyPart',
    topicId: 'illness',
    sourcePages: [199],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'legacy-function',
    executorStatus: 'ready',
    legacyTopicId: 'illness',
    notes: 'Use only the verified H6 figure → body-part mapping from p199. Canonical method-scoped legacy executor is wired and tested; missing source entries remain unresolved rather than invented.',
  }),

  'pregnancy.p191.genderH5': method({
    kashfMethodId: 'pregnancy.p191.genderH5',
    kashfIntentId: 'pregnancy.gender',
    topicId: 'children',
    sourcePages: [191],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'children',
    notes: 'Canonical p191 method: read the sex from the masculine/feminine classification of H5 only. The four androgynous figures remain unresolved. Do not blend the alternative p192-p194 gender procedures into this verdict.',
  }),

  // ── FAMILY + HEALTH canonical slice -----------------------------------
  'pregnancy.p191.twinsMujassad': method({
    kashfMethodId: 'pregnancy.p191.twinsMujassad',
    kashfIntentId: 'pregnancy.twins',
    topicId: 'children',
    sourcePages: [191],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p191 states that a مجسدا figure indicates twins. The canonical classifier exposes mujassad-dakhil (fixed) and mujassad-kharij (mutable), but this passage does not define whether مجسدا means either class, both classes, or a distinct source taxonomy. Do not equate it with fixed/mutable by name similarity; keep runtime blocked until the exact source mapping is certified.',
  }),

  'pregnancy.p191.existsH5SilentEmpty': method({
    kashfMethodId: 'pregnancy.p191.existsH5SilentEmpty',
    kashfIntentId: 'pregnancy.exists',
    topicId: 'children',
    sourcePages: [191],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical body rule: H5 silent => pregnancy true; H5 empty => pregnancy false. Figures that are neither silent nor empty remain unresolved by this rule. Do not substitute benefic/malefic.',
  }),

  'pregnancy.p191.childSafetyH1H6H8': method({
    kashfMethodId: 'pregnancy.p191.childSafetyH1H6H8',
    kashfIntentId: 'pregnancy.childSafety',
    topicId: 'children',
    sourcePages: [191],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p191 child-safety executor is wired. H1 pure benefic gives the source safety testimony; H1 pure malefic gives fear/concern. H6+H8 both pure malefic activate the separate severe source warning that the fetus/child may emerge dead. Mixed figures are not collapsed. The severe clause is treated as a risk statement, not as a certain death verdict.',
  }),

  'pregnancy.p191.deliveryDifficultyH1H5H15': method({
    kashfMethodId: 'pregnancy.p191.deliveryDifficultyH1H5H15',
    kashfIntentId: 'pregnancy.deliveryDifficulty',
    topicId: 'children',
    sourcePages: [191, 194],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p191 delivery-difficulty executor is wired. H1+H5 both masculine give the explicit ease sign, with the source noting greater force when both are mutable. A fixed H5 gives the explicit difficulty sign, with H1 and H15 exposed as testimony rather than converted into an invented vote. If ease and difficulty signs coexist, the executor reports conflicting source signs instead of choosing one silently.',
  }),

  'pregnancy.p191-192.miscarriageRedH7NakisH8': method({
    kashfMethodId: 'pregnancy.p191-192.miscarriageRedH7NakisH8',
    kashfIntentId: 'pregnancy.miscarriageRisk',
    topicId: 'children',
    sourcePages: [191, 192],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical miscarriage-risk route uses only the cross-page printed seam: Humra/Red (2122) in H7 together with Ankis/Nakis/Shallow Head (2221) in H8 is the explicit miscarriage sign. Absence of this exact pair does NOT prove safety and does not invert the rule. Other p192-p193 fetus-risk branches remain separate source methods and do not vote with this route.',
  }),

  'pregnancy.p192.genderH5H11InOut': method({
    kashfMethodId: 'pregnancy.p192.genderH5H11InOut',
    kashfIntentId: 'pregnancy.genderAlternativeP192',
    topicId: 'children',
    sourcePages: [192],
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Body-source alternative gender method: benefic external figures in H5 and H11 indicate male; benefic internal figures there indicate female. It remains reference-only and never votes against the selected p191 H5 gender route.',
  }),

  'pregnancy.p192.genderParityH1H6H8H12': method({
    kashfMethodId: 'pregnancy.p192.genderParityH1H6H8H12',
    kashfIntentId: 'pregnancy.genderParityAlternativeP192',
    topicId: 'children',
    sourcePages: [192],
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Body-source alternative gender procedure derives from H1,H6,H8,H12 and judges the resulting odd/even outcome as male/female. Keep as reference-only unless explicitly promoted after a separate executor audit; it does not participate in q-gender.',
  }),

  'pregnancy.p192.maternalSafetyH6H8H12': method({
    kashfMethodId: 'pregnancy.p192.maternalSafetyH6H8H12',
    kashfIntentId: 'pregnancy.maternalSafety',
    topicId: 'children',
    sourcePages: [192],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p192 gives a distinct maternal-safety branch: H6,H8,H12 benefic indicate that the mother is saved/safe. This is not fetal safety, miscarriage risk, gender, or delivery difficulty. No inverse medical verdict is authorized merely because one house fails the positive condition. No UI route is enabled until a dedicated client-safe executor/policy is approved.',
  }),

  'pregnancy.p192.monthCount': method({
    kashfMethodId: 'pregnancy.p192.monthCount',
    kashfIntentId: 'pregnancy.monthCount',
    topicId: 'children',
    sourcePages: [192],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p192 gives two month-count routes: strike the “third” in the pregnancy house and reduce nine-by-nine, with the remainder as months; alternatively use the balance figure as the month count. The exact computational meaning of the “third” operation and the precedence/reconciliation between the two routes are not closed for runtime. Preserve both; do not invent arithmetic or choose one silently.',
  }),

  'child.p194.existenceH1H5Nature': method({
    kashfMethodId: 'child.p194.existenceH1H5Nature',
    kashfIntentId: 'child.existence',
    topicId: 'children',
    sourcePages: [194],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p194 treats H1 matching H5 in nature as a child indication, then gives a separate branch: a figure that is neither male nor female and is overturned/mutable indicates an empty womb. This is a child-existence intent, not a gate for the H6/H8 health trajectory. Runtime stays pending until “matches in nature” is bound to one source-certified taxonomy.',
  }),

  'child.p194.wellbeingH5H16': method({
    kashfMethodId: 'child.p194.wellbeingH5H16',
    kashfIntentId: 'child.wellbeing',
    topicId: 'children',
    sourcePages: [194],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p194 wellbeing branch is distinct from health: H5+H16 both benefic => good fortune/improved condition/much money; both malefic => low condition; one benefic and one malefic => medium condition. Keep separate from H6/H8 health and from current-illness recovery.',
  }),

  'pregnancy.p194.deliveryH5Weight': method({
    kashfMethodId: 'pregnancy.p194.deliveryH5Weight',
    kashfIntentId: 'pregnancy.deliveryAlternativeP194',
    topicId: 'children',
    sourcePages: [194],
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Body-source p194 alternative/supporting delivery statements: heavy H5 indicates difficult birth; benefic H5 (external or internal) indicates easy birth. Reference-only in the canonical app: q-birth-ease remains on the selected p191 H1/H5/H15 method and does not vote with this passage.',
  }),

  'child.p194.healthTrajectoryH6H8': method({
    kashfMethodId: 'child.p194.healthTrajectoryH6H8',
    kashfIntentId: 'child.healthTrajectory',
    topicId: 'children',
    sourcePages: [194],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p194 child-health trajectory executor is wired as two separate source witnesses: pure malefic H6 gives the explicit childhood-pains warning; H8 pure malefic gives low hope, while H8 pure benefic gives improvement as the child grows. Mixed or unmentioned branches remain unresolved. This method is not current-illness recovery and does not aggregate H6+H8 into one invented score.',
  }),

  'lifespan.p178.elementCountToHouse': method({
    kashfMethodId: 'lifespan.p178.elementCountToHouse',
    kashfIntentId: 'lifespan.duration',
    topicId: 'generalReading',
    sourcePages: [178],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Printed p178 source procedure is verified: aggregate the four elements, reduce by 16, walk the remainder over houses, then read the landing figure and its source number in that house; angle/inclined/cadent class converts that number to years/months/days. Runtime remains disabled because the exact “figure number in that house” lookup used by this procedure is not yet certified as a canonical operational table/consumer. Do not substitute dignity values, Hawi house-state values, or p264 life stages.',
  }),

  'lifespan.p264.stagesH11H9H7': method({
    kashfMethodId: 'lifespan.p264.stagesH11H9H7',
    kashfIntentId: 'lifespan.stages',
    topicId: 'friendsHope',
    sourcePages: [264],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p264 life-stages executor is wired as a descriptive three-stage profile only: H11 beginning of life, H9 middle, H7 end. Each stage exposes the figure and the verified p133-134 planetary attribution. It does not calculate lifespan duration and does not invent an aggregate good/bad score.',
  }),

  'mother.p257.statusDayNight': method({
    kashfMethodId: 'mother.p257.statusDayNight',
    kashfIntentId: 'mother.status',
    topicId: 'motherRules',
    sourcePages: [257],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Body-source mother rule. Night: house quality plus White/Road in angles or succedents vs cadents. Day: judge by Venus figures. Existing helper is incomplete and must not be reused unchanged.',
  }),

  'hidden.p185.recursiveQuarterFireAir': method({
    kashfMethodId: 'hidden.p185.recursiveQuarterFireAir',
    kashfIntentId: 'hidden.locationRecursiveQuarterP185',
    topicId: 'hiddenTreasure',
    sourcePages: [185],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p185 first combines fire-point count with the relevant name/owner-name count, reduces by fours to choose east/west/south/north, then repeats inside the selected quarter using air points and the name, recursively narrowing the location. The same printed passage says there are sixteen places, each divided into four, yet concludes with أربعة وتسعين (94). Preserve the printed 94 and the apparent 16×4 conflict; do not normalize it to 64, infer a missing subdivision rule, or execute this method until the conflict is source-resolved.',
  }),

  'hidden.p186.nameDayAbjadQuarter': method({
    kashfMethodId: 'hidden.p186.nameDayAbjadQuarter',
    kashfIntentId: 'hidden.directionNameDayQuarterP186',
    topicId: 'hiddenTreasure',
    sourcePages: [186],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p186 is a separate directional procedure: stand in the middle of the place facing the qibla, total the querent name, mother name and current day by the large abjad, reduce by four, then map remainder 1=east, 2=west, 3=south, 4=north. It requires dedicated name/day inputs and abjad calculation; it is not inferred from the ordinary geomantic board and is not a supporting vote for the p188 quarter-cast route.',
  }),

  'hidden.p186.tamtamFourQuarterCasts': method({
    kashfMethodId: 'hidden.p186.tamtamFourQuarterCasts',
    kashfIntentId: 'hidden.directionTamtamQuarterP186',
    topicId: 'hiddenTreasure',
    sourcePages: [186],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'additional-cast',
    executorStatus: 'pending',
    notes: 'Printed p186 Tamtam method divides the place into four directions and casts one figure for each. Internal benefic indicates the object in that quarter; external malefic indicates nothing there. The special 2-benefic/2-malefic branch explicitly derives TWO intermediate figures and then combines them for the final figure. This needs a dedicated four-cast flow and must not be collapsed into, aggregated with, or used as fallback for p188 hidden.p188.quarterDirection.',
  }),

  'hidden.p187.kindRootDirection': method({
    kashfMethodId: 'hidden.p187.kindRootDirection',
    kashfIntentId: 'hidden.kindAndRootDirectionP187',
    topicId: 'hiddenTreasure',
    sourcePages: [187],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p187 requires extracting TWO figures from the angles and then a third figure from those two. Its element gives the hidden thing context: fire=near fire, air=suspended/in air, water=near water, earth=buried in earth. Root placement then maps mothers=east, daughters=west and balances=south, while the munshaat branch prints the difficult token ناحية الجاه. That token is not source-secure as “north”; runtime is blocked and no north or other direction may be inferred from symmetry, Hawi, or another chapter.',
  }),

  'hidden.p188.isStillThere': method({
    kashfMethodId: 'hidden.p188.isStillThere',
    kashfIntentId: 'hidden.isStillThere',
    topicId: 'hiddenTreasure',
    sourcePages: [188],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p188 executor is wired: H1,H2,H4,H13,H14,H15 must all be explicitly benefic (saad) for the hidden thing to be in the tested place; otherwise the source says it is not there. No majority rule and no promotion of mixed tendency to benefic. This does not prove an unspecified treasure exists from nothing.',
  }),

  'hidden.p188.quarterDirection': method({
    kashfMethodId: 'hidden.p188.quarterDirection',
    kashfIntentId: 'hidden.direction',
    topicId: 'hiddenTreasure',
    sourcePages: [188],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'additional-cast',
    executorStatus: 'pending',
    notes: 'Printed p188 divides the suspected place into four quarters and casts one figure per direction: internal benefic indicates the suspected quarter; external malefic indicates nothing there, until four figures are completed. This requires a dedicated four-cast input flow and cannot be inferred from the existing board. It is the single selected q-dig-direction route; the p185 recursive arithmetic, p186 name/day and Tamtam methods, p187 root method and p190 recursive-triangle method are separate alternatives and never vote with it.',
  }),

  'well.p188.recast1468': method({
    kashfMethodId: 'well.p188.recast1468',
    kashfIntentId: 'well.result',
    topicId: 'hiddenTreasure',
    sourcePages: [188],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'recast-board',
    executorStatus: 'pending',
    notes: 'Printed p188 says to make H1,H4,H6,H8 the new mothers and judge derived H4 and angles as benefic+internal. Under the current strict dakhil classifier the inward condition is unreachable: exhaustive enumeration of all 65,536 valid source-mother combinations found 0 with derived H1,H4,H7,H10 all dakhil (maximum 3 inward-benefic). Do not broaden inward to fixed/mixed without source evidence. Existing legacy helper using original houses is not equivalent. This method answers attainment only; water depth is a separate intent.',
  }),

  'hiddenDepth.p188-189.openElementLengths': method({
    kashfMethodId: 'hiddenDepth.p188-189.openElementLengths',
    kashfIntentId: 'hidden.depthByOpenElements',
    topicId: 'hiddenTreasure',
    sourcePages: [188, 189],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed pp188-189 gives the element-length scale fire=one finger, air=one span, water=one cubit, earth=one stature, then instructs using the indicator figure’s OPEN elements with a letter/opposites arrangement. The worked example totals two fingers and one span. Runtime remains blocked until the exact open-element extraction, figure/letter ordering and measurement accumulation are Golden-Testable from the source; do not substitute ordinary element classification or the Tamtam depth table.',
  }),

  'waterDepth.p189-190.tamtamTable': method({
    kashfMethodId: 'waterDepth.p189-190.tamtamTable',
    kashfIntentId: 'well.waterDepthTamtam',
    topicId: 'hiddenTreasure',
    sourcePages: [189, 190],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed Tamtam water-depth procedure derives one figure from H1+H12, a second from H12+H9, then derives a third from those two and applies the p189-190 figure-specific depth table. Keep this method separate from the open-element length framework. Runtime is blocked until the complete figure identities/table measurements and derivation chain are captured in a Golden-Testable executor; do not merge table values with the element-length scale.',
  }),

  'hidden.p190.nearFarElementDirection': method({
    kashfMethodId: 'hidden.p190.nearFarElementDirection',
    kashfIntentId: 'hidden.nearFarAndElementDirection',
    topicId: 'hiddenTreasure',
    sourcePages: [190, 191],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed pp190-191 give a separate near/far/path-and-direction rule: Moon and Mars indicate near; Mercury and Jupiter indicate a rough road/fear; Saturn in H1 indicates a thorny road. H1 element gives direction: air=north, fire=east, earth=qibla, water=west. This is a distinct procedure with its own planetary/element prerequisites and is not a supporting vote for q-dig-direction or the depth methods.',
  }),

  'hidden.p190-191.recursiveHouseTriangles': method({
    kashfMethodId: 'hidden.p190-191.recursiveHouseTriangles',
    kashfIntentId: 'hidden.locationRecursiveHouseTriangles',
    topicId: 'hiddenTreasure',
    sourcePages: [190, 191],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed pp190-191 say that when the hidden thing is inside a house, divide the house into four directions and اضرب لكل جهة مثلثة, use empty/full results to choose the quarter, subdivide that quarter again, and repeat until the exact spot remains. The technical operation مثلثة is not defined in this passage. Runtime is blocked; do not reduce مثلثة to one ordinary figure and do not replace this method with the p185 or p188 quarter procedures.',
  }),

  'lostItem.p202.returnH6H8': method({
    kashfMethodId: 'lostItem.p202.returnH6H8',
    kashfIntentId: 'lostItem.return',
    topicId: 'lostAnimal',
    sourcePages: [202],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p202 executor is wired: BOTH H6 and H8 must each be pure benefic (saad) and strictly internal (dakhil). The source says otherwise it does not return. Mixed figures and mujassad/fixed/mutable movement classes are not coerced into benefic+internal. This method is shared by lost-item and lost-animal routes and is not a theft-attribution rule.',
  }),

  'marriage.p204.dowryH8': method({
    kashfMethodId: 'marriage.p204.dowryH8',
    kashfIntentId: 'marriage.dowryAmount',
    topicId: 'marriage',
    sourcePages: [204],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p204 H8 executor: an explicitly benefic figure indicates a large mahr. The immediately following benefic/malefic clause belongs to H10 family status, so H8 malefic or mixed does NOT authorize a small-mahr verdict. Those branches remain unresolved.',
  }),

  'siblings.p182.seniority': method({
    kashfMethodId: 'siblings.p182.seniority',
    kashfIntentId: 'siblings.seniority',
    topicId: 'siblings',
    sourcePages: [182],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'siblings',
    notes: 'Canonical p182 sibling-seniority executor is wired to H3 only. Jamaa/קהלה (2222) is the source sign for elders, especially paternal elders; Nakis/שפל ראש (2221) also indicates elders. Other H3 figures remain unresolved by this exact rule. The method does not identify a named sibling or infer that an unlisted figure means younger.',
  }),

  'marriage.p204.previousStatusH7inH10': method({
    kashfMethodId: 'marriage.p204.previousStatusH7inH10',
    kashfIntentId: 'marriage.previousStatus',
    topicId: 'marriage',
    sourcePages: [204],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'marriage',
    notes: 'Corrected against primary Arabic p204: the H7 figure must occur in H10. If that repeated figure is mutable (منقلب) => divorced (مطلقة); if fixed (ثابت) => virgin (بكر). If H7 does not recur in H10, or the repeated figure is outside the four source-defined mutable/four fixed classes, this rule remains unresolved. It does not distinguish widowhood.',
  }),

  // ── LOVE + MARRIAGE canonical slice -----------------------------------
  'marriage.p210.generalMarriageH1H2H7H8H10Judge': method({
    kashfMethodId: 'marriage.p210.generalMarriageH1H2H7H8H10Judge',
    kashfIntentId: 'marriage.suitability',
    topicId: 'marriage',
    sourcePages: [210, 211],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical pp210-211 general-marriage executor is wired. It preserves the source roles of H1/H2 for the man and marriage, H7/H8 for the woman, H10 for what occurs between them and H15 for the outcome; it then performs the explicit H1+H5 derivation for the final good/opposite judgment. Only source-explicit branches are asserted, and mixed testimony remains unresolved.',
  }),

  'love.p205.directLoveH1PlacementH15': method({
    kashfMethodId: 'love.p205.directLoveH1PlacementH15',
    kashfIntentId: 'love.doesPersonLoveMe',
    topicId: 'marriage',
    sourcePages: [205],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Visual recheck of the printed p205 scan confirms H15: انظر البيت الخامس عشر بالنسبة إلى الطالع. The prior H5 repair was based on a text-layer misread and is reversed. The H1/ascendant figure is judged by recurrence/placement; the printed negative list still names 6,8,3,12 while the standard cadents are 3,6,9,12. Runtime remains blocked until that placement anomaly, the H15↔ascendant نسبة relation, and the final وإن كان في قبضتك clause are source-closed. Do not substitute p204 attention or p206 favor/desire.',
  }),

  'love.p204.attentionFireRows1713': method({
    kashfMethodId: 'love.p204.attentionFireRows1713',
    kashfIntentId: 'love.attention',
    topicId: 'marriage',
    sourcePages: [204],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p204 attention/look executor is wired. It uses only the explicit p204 condition: fire row of H1 open + fire row of H7 open + fire row of H13 joined/closed => both look at each other and also at others. Other row combinations remain unresolved by this exact method. The similar p170 practical rule is not blended into this verdict, and this method does not answer whether love exists.',
  }),

  'love.p206.womanFavorH7H11ThenH5': method({
    kashfMethodId: 'love.p206.womanFavorH7H11ThenH5',
    kashfIntentId: 'love.womanFindsFavor',
    topicId: 'marriage',
    sourcePages: [206],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p206 woman-favor clause. Combine H7+H11, then combine that result with H5. Pure benefic means the woman finds favor in his eyes; pure malefic means she does not; mixed remains unresolved. This is one-directional favor, not mutual chemistry or a general love verdict.',
  }),
  'desire.p206.querentWantsH7H11ThenH5': method({
    kashfMethodId: 'desire.p206.querentWantsH7H11ThenH5',
    kashfIntentId: 'desire.querentWantsMatter',
    topicId: 'marriage',
    sourcePages: [206],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p206 querent-desire executor is wired. Combine H7+H11, then combine that generated figure with H5. Pure benefic means the querent wants the matter; pure malefic means the opposite; mixed remains unresolved. The separate p206 woman-favor clause uses the same derivation but remains a different method/intent and never votes into this result.',
  }),

  'marriage.p211.dissolutionH7StateMatrix': method({
    kashfMethodId: 'marriage.p211.dissolutionH7StateMatrix',
    kashfIntentId: 'marriage.dissolution',
    topicId: 'marriage',
    sourcePages: [210, 211],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p211 H7 matrix is source-closed against scan p211. Internal, external, fixed and mutable branches are all implemented. Internal/external figures use their pure source fortune. Fixed/mutable figures require the catalogue mixed tendency to realize the explicit سعد/نحس split in the source; that promotion is method-local to p211 and must not leak to other methods. Benefic-external remains only possible separation, not certain separation; the adverse mutable source phrase that leaving is preferable is preserved as source wording, not converted into independent advisor advice.',
  }),

  // ── MONEY + ECONOMY canonical slice -----------------------------------
  'debt.p179.creditorDebtorWalking': method({
    kashfMethodId: 'debt.p179.creditorDebtorWalking',
    kashfIntentId: 'loan.repayment',
    topicId: 'loan',
    sourcePages: [179],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p179 assigns H1 to the creditor, derives the debtor from H7+H9 and the money from H2+H12, then branches on “walked two / walked three”, absence from “the hand”, and the named tokens Farah and Bakr. The scan does not define those computational terms sufficiently for canonical execution. Do not identify Farah/Bakr with modern figure names, do not reinterpret hand as the current chart array, and do not invent walk arithmetic. The exact debt/repayment UI route must fail closed here rather than fall back to the external p234 method.',
  }),

  'money.p179.sourceByIncomingHonorHouse': method({
    kashfMethodId: 'money.p179.sourceByIncomingHonorHouse',
    kashfIntentId: 'money.source',
    topicId: 'money',
    sourcePages: [179],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p179 money-source executor is wired. If H2 is pure benefic, locate Incoming Honor (2211) in the twelve topical houses and report the source by the nature/title of the house or houses where it appears. Multiple occurrences remain multiple source channels; none are ranked. If Money Incoming (2121) itself is in H2, its topical recurrences are exposed separately as acquisition-judgment testimony and are not silently merged into the Incoming-Honor source rule. Mixed/non-benefic H2 does not activate this source clause. The distinct p179 malefic-H2 exceptions and p181 alternate/modulo method are not imported.',
  }),

  'money.p180.livelihoodH10Invert': method({
    kashfMethodId: 'money.p180.livelihoodH10Invert',
    kashfIntentId: 'money.livelihood',
    topicId: 'money',
    sourcePages: [180],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p180 livelihood executor is wired. It inverts every open/closed row of H10, identifies the resulting figure, and traces its recurrence in houses 1-12. A pure-benefic result placed in an angle supports expanded livelihood; cadent placement is unfavorable. If the result occurs in both angle and cadent houses, or only in an unstated placement, the method remains unresolved rather than inventing a priority rule.',
  }),

  'money.p181.recast25811': method({
    kashfMethodId: 'money.p181.recast25811',
    kashfIntentId: 'money.acquire',
    topicId: 'money',
    sourcePages: [181],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p181 secondary-board executor is wired: original H2,H5,H8,H11 become the four mothers of a fresh board. In that recast board H1,H2,H4,H7,H10 must each be strictly internal (dakhil); when all qualify, the source says the money is obtained. Failure of the positive condition remains unresolved because this exact clause does not state the inverse. The preceding p181 2/6/8/10 parity method remains a separate alternative and is not aggregated.',
  }),

  'money.p181.otherBookRemainder': method({
    kashfMethodId: 'money.p181.otherBookRemainder',
    kashfIntentId: 'money.externalRemainderOracle',
    topicId: 'money',
    sourcePages: [181],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    sourceConfidence: 'source-conflict',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The passage is explicitly introduced by ومن غير الكتاب. It says to total the sixteen figures and reduce “two by two”, where remainder 1 means no money and remainder 2 means abundant money, then immediately gives a 1–7 remainder table for the source of money. The printed source is internally incompatible as an executable remainder system. Preserve it for source review only; do not silently change the divisor to seven, suppress branches, or let it vote with the selected p181 recast method.',
  }),

  'money.p182.h2h10Outlook': method({
    kashfMethodId: 'money.p182.h2h10Outlook',
    kashfIntentId: 'money.generalCondition',
    topicId: 'money',
    sourcePages: [182],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p182 general money/livelihood route. Combine H2 (money) with H10 (livelihood); judge only the resulting figure’s canonical benefic/malefic class. Mixed remains non-binary. This route does not execute p180 person-to-person amount comparison, p181 attainment alternatives, p179 source-of-money, p182 magnitude, or any legacy topic supporting bundle.',
  }),

  'money.p182.lawfulnessInclination': method({
    kashfMethodId: 'money.p182.lawfulnessInclination',
    kashfIntentId: 'money.lawfulness',
    topicId: 'money',
    sourcePages: [182],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p182 explicitly derives a figure from H9+H11 and says: if the resulting figure “inclines to” H9 the money is lawful, and if it inclines to H11 it is unlawful. The passage does not define the operational meaning of that inclination. Preserve the rule as source-backed knowledge but do not invent a house-affinity, recurrence, dignity, element, or movement test for “inclines”.',
  }),

  'inheritance.p180.elementComposite': method({
    kashfMethodId: 'inheritance.p180.elementComposite',
    kashfIntentId: 'inheritance.whoInheritsWhom',
    topicId: 'deathInheritance',
    sourcePages: [180],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Body-source inheritance method determines which side inherits the other through the stated element-row composites. It does not calculate shares, amounts, or inheritance disputes.',
  }),

  // ── TRAVEL + MISSING canonical slice ----------------------------------
  'travel.p238.timeSelectionH9H4': method({
    kashfMethodId: 'travel.p238.timeSelectionH9H4',
    kashfIntentId: 'travel.timeSelection',
    topicId: 'travel',
    sourcePages: [238],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    legacyTopicId: 'travel',
    notes: 'Canonical time-selection rule judges a proposed departure time: Road, Ahyan/Nesu Rosh, or Incoming Honor in H9 / the head / querent house, with H4 benefic. The existing timing helper has a named-figure table defect and must not run until repaired. This method does not calculate a future date from nothing.',
  }),

  'travel.p239.profitEarthRowH2': method({
    kashfMethodId: 'travel.p239.profitEarthRowH2',
    kashfIntentId: 'travel.profit',
    topicId: 'travel',
    sourcePages: [239],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'v57 preserves the profit rule, but the exact source input denoted by the earth row of the point/area is not sufficiently resolved for canonical construction. Hebrew knowledge is indexed; runtime remains source-blocked until the input is closed.',
  }),

  'travel.p239.seaOrLandByElement': method({
    kashfMethodId: 'travel.p239.seaOrLandByElement',
    kashfIntentId: 'travel.seaOrLand',
    topicId: 'travel',
    sourcePages: [239],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'v57 preserves the sea/land element mapping, but the preceding two-figure construction is unresolved and the Hebrew fire branch omits the Arabic return-by-sea clause. Runtime remains source-blocked until v57 is explicitly corrected/closed.',
  }),

  'travel.p242.roadDangerH7Element': method({
    kashfMethodId: 'travel.p242.roadDangerH7Element',
    kashfIntentId: 'travel.roadDanger',
    topicId: 'travel',
    sourcePages: [242],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Body-source danger classification uses H7 element: fire=robbers; air=road animals and the like; water=drowning/theft/fighting; earth=snakes/scorpions/ground harms. The current generic element resolver must be verified before reuse.',
  }),

  'travel.p244.returnH1H2H9': method({
    kashfMethodId: 'travel.p244.returnH1H2H9',
    kashfIntentId: 'travel.return',
    topicId: 'travel',
    sourcePages: [244],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p244 traveler-return executor is wired conservatively. H1/H2/H9 all pure benefic and strictly internal support return in goodness and joy. H1/H2/H9 all pure malefic expose the source hardship / possible non-return branch, but are not converted into a certain no-return verdict. Split or mixed testimony remains unresolved. The separate H5 companion rule is not imported.',
  }),

  'missing.p249.returnAnglesJudge': method({
    kashfMethodId: 'missing.p249.returnAnglesJudge',
    kashfIntentId: 'missing.return',
    topicId: 'missingPerson',
    sourcePages: [249],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p249 missing-return executor is wired conservatively. The four angles H1/H4/H7/H10 must all be pure benefic and strictly internal, and H15 must give the same benefic/internal supporting testimony before the source return sign is exposed. Failure of the positive condition is not inverted into non-return. The Hebrew source clause explicitly speaks of return of males, so the executor preserves that scope and does not silently generalize it to every missing-person case.',
  }),

  'missing.p249.locationDirectionUnresolved': method({
    kashfMethodId: 'missing.p249.locationDirectionUnresolved',
    kashfIntentId: 'missing.location',
    topicId: 'missingPerson',
    sourcePages: [249, 250],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Body text distinguishes whether the absent person is in the city using the four angles and says to inspect direction, but the exact body-source directional operation is not sufficiently closed. Do not import the later Nuzhat fugitive-direction method.',
  }),

  'travel.external.p246.directionNuzhat': method({
    kashfMethodId: 'travel.external.p246.directionNuzhat',
    kashfIntentId: 'travel.direction',
    topicId: 'travel',
    sourcePages: [246],
    sourceLayer: 'added-from-other-book',
    attributedSourceBook: 'Nuzhat al-Uqul',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Explicit Nuzhat addition: dominant element gives direction (fire east, air west, water sea, earth qibla/south). Knowledge-only by default; no canonical body direction method has been selected.',
  }),

  'travel.external.p247.compareTwoTrips': method({
    kashfMethodId: 'travel.external.p247.compareTwoTrips',
    kashfIntentId: 'travel.compareTwoTrips',
    topicId: 'travel',
    sourcePages: [247],
    sourceLayer: 'added-from-other-book',
    attributedSourceBook: 'Nuzhat al-Uqul',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The two-trips comparison is inside the explicit Nuzhat addition. Retain for learning only unless explicitly selected later.',
  }),

  'fugitive.external.p250.nuzhat': method({
    kashfMethodId: 'fugitive.external.p250.nuzhat',
    kashfIntentId: 'fugitive.capture',
    topicId: 'missingPerson',
    sourcePages: [250],
    sourceLayer: 'added-from-other-book',
    attributedSourceBook: 'Nuzhat al-Uqul',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Fugitive material after the return marker is explicitly from Nuzhat al-Uqul. It must not be executed as body-source Kashf runtime.',
  }),

  // ── CAREER + AUTHORITY canonical slice --------------------------------
  'authority.p256.honorConditionH10Planet': method({
    kashfMethodId: 'authority.p256.honorConditionH10Planet',
    kashfIntentId: 'authority.honorCondition',
    topicId: 'authorityState',
    sourcePages: [256],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p256 H10-planet executor is wired to the source-verified p133-134 planetary map. Sun => strength of honor/rank; Jupiter or Venus => good/completion; Saturn => lack of benefit, gloom and distress. Moon, Mercury and Mars remain unresolved by this p256 excerpt; do not turn this into a binary fame prediction.',
  }),

  'authority.p257.appointmentH1H10Planet': method({
    kashfMethodId: 'authority.p257.appointmentH1H10Planet',
    kashfIntentId: 'authority.appointmentStays',
    topicId: 'authorityState',
    sourcePages: [257],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p257 executor combines H1+H10 and judges the resulting figure by the source-verified planetary attribution. Sun/Moon or Jupiter/Venus => the appointment/authority completes; every other verified planet => it does not. Never substitute a benefic/malefic proxy for the planetary rule.',
  }),

  'authority.p257.rulerConditionH7H10': method({
    kashfMethodId: 'authority.p257.rulerConditionH7H10',
    kashfIntentId: 'authority.rulerCondition',
    topicId: 'authorityState',
    sourcePages: [257],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p257 ruler-condition executor combines H7+H10. Source-explicit benefic => good and malefic => bad. Canonical mixed classification stays unresolved because this rule does not state a mixed branch. This is distinct from appointment persistence.',
  }),

  'career.p266.returnToOffice': method({
    kashfMethodId: 'career.p266.returnToOffice',
    kashfIntentId: 'career.returnToOffice',
    topicId: 'authorityState',
    sourcePages: [266],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'authorityState',
    notes: 'Canonical p266 return-to-office executor is wired directly from the body-source clause rather than the broad authorityState helper. H1 must be pure benefic and strictly internal, its same figure must recur in another strong/angle house (H4/H7/H10; H10 is explicitly named), and H16 / al-aqiba must be pure benefic to support the return. Pure-malefic H1 activates the explicit opposite branch. Mixed H1 or incomplete positive testimony remains unresolved. The original H1 occurrence is not counted as a recurrence.',
  }),

  'profession.p254.h9Planet': method({
    kashfMethodId: 'profession.p254.h9Planet',
    kashfIntentId: 'profession.type',
    topicId: 'authorityState',
    sourcePages: [133, 134, 254],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'authorityState',
    notes: 'Canonical p254 profession executor is wired directly from the source. H9 uses the complete p133-134 attribution table for all 16 figures, including Head=1212 and Tail=1112. H10/H11 are only a separate one-way ease-of-work qualifier and both must be pure saad; mixed testimony is not promoted and a failed qualifier is not inverted into hard work. The method reports the source craft/profession, not a modern best-career recommendation.',
  }),

  // ── CONFLICT + THEFT canonical slice --------------------------------
  'theft.p224.recoveryH8': method({
    kashfMethodId: 'theft.p224.recoveryH8',
    kashfIntentId: 'theft.recovery',
    topicId: 'theft',
    sourcePages: [224],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'theft',
    notes: 'Source-scoped p224 H8 executor: pure benefic => recovered, pure malefic => not recovered. Mixed figures remain unresolved; the legacy theft helper is not invoked.',
  }),

  'theft.p224.relationshipH7Recurrence': method({
    kashfMethodId: 'theft.p224.relationshipH7Recurrence',
    kashfIntentId: 'theft.thiefRelationship',
    topicId: 'theft',
    sourcePages: [225, 231, 232, 233],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Body-source relationship/proximity method follows where the H7 figure recurs and judges the connection by that house. It can classify relation/proximity; it does not identify a named thief.',
  }),

  'theft.p225.thiefDescriptionH7': method({
    kashfMethodId: 'theft.p225.thiefDescriptionH7',
    kashfIntentId: 'theft.thiefDescription',
    topicId: 'theft',
    sourcePages: [224, 225],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical thief-profile executor uses the p225 instruction to read H7 and the complete p231–233 sixteen-figure description table. It is descriptive only: no named-person identification, guilt proof or name-letter generation is inferred.',
  }),

  'dispute.p212.reconciliationH1H7': method({
    kashfMethodId: 'dispute.p212.reconciliationH1H7',
    kashfIntentId: 'dispute.reconciliation',
    topicId: 'disputes',
    sourcePages: [212],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p212 reconciliation executor is wired. Generate one figure from H1+H7. A pure benefic generated figure gives the explicit source verdict that the two sides reconcile. Pure malefic, mixed, or unknown generated figures remain unresolved because p212 does not state the converse in this clause. Mediator identity clauses remain outside this yes/no executor.',
  }),

  'dispute.p213.winnerStrengthUnresolved': method({
    kashfMethodId: 'dispute.p213.winnerStrengthUnresolved',
    kashfIntentId: 'dispute.whoWins',
    topicId: 'disputes',
    sourcePages: [213],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Body-source winner/loser method is identified (H13+balance for querent, H14 for respondent, then multiplicity/strength and tie-break house groups), but the exact source semantics of “strength/multiplicity of force” are not closed. No code until that term is resolved.',
  }),

  'partnership.p212.operationUnresolved': method({
    kashfMethodId: 'partnership.p212.operationUnresolved',
    kashfIntentId: 'partnership.goodOrBad',
    topicId: 'partnership',
    sourcePages: [212],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p212 gives partnership indications from H1/H7 and H5/H7 and also a 2-by-2 remainder rule, but the exact operation/input denoted by the total is not sufficiently closed. Do not merge the variants or invent the operand.',
  }),

  'fear.p273.punishmentSigns': method({
    kashfMethodId: 'fear.p273.punishmentSigns',
    kashfIntentId: 'fear.punishment',
    topicId: 'fear',
    sourcePages: [273],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'legacy-function',
    executorStatus: 'pending',
    legacyTopicId: 'fear',
    notes: 'Body-source punishment-fear rule requires Incoming Honor in H10, Incoming Threshold in H5, Ahyan/Nesu Rosh in H1 OR the enemy house, and H4 benefic. Existing computeFearOfPunishment checks the H1 branch but omits the alternative enemy-house branch.',
  }),

  'war.external.p213-217.nonBody': method({
    kashfMethodId: 'war.external.p213-217.nonBody',
    kashfIntentId: 'war.outcome',
    topicId: 'disputes',
    sourcePages: [213, 214, 215, 216, 217],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The city/war/winner material after the explicit ومن غير الكتاب marker is retained for learning only. It must not become the runtime fallback for dispute or war questions.',
  }),

  'prisoner.causeOfImprisonment.unsupported': method({
    kashfMethodId: 'prisoner.causeOfImprisonment.unsupported',
    kashfIntentId: 'prisoner.causeOfImprisonment',
    topicId: 'prisoner',
    sourcePages: [272, 273],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Audited body-source prisoner rules judge outcome/exit conditions, not the identity of the person responsible for causing the imprisonment. Do not infer a culprit from house symbolism.',
  }),

  'conflict.victoryGoalMixedScope.unsupported': method({
    kashfMethodId: 'conflict.victoryGoalMixedScope.unsupported',
    kashfIntentId: 'conflict.victoryGoalMixedScope',
    topicId: 'disputes',
    sourcePages: [212, 213, 267],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The UI question mixes defeating an opponent with succeeding in a personal objective. Those belong to dispute.whoWins and hope.fulfillment respectively and must be split before canonical routing.',
  }),

  'business.attention.unsupported': method({
    kashfMethodId: 'business.attention.unsupported',
    kashfIntentId: 'business.otherPartyAttention',
    topicId: 'partnership',
    sourcePages: [212],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited body-source method has been selected for whether a business counterparty is still mentally committed or has shifted attention elsewhere. Do not reuse the p204 love-attention method across domains.',
  }),

  // ── SPIRITUAL + MISC source-safety slice -----------------------------
  'spiritual.p167.hiddenActionAirRows46815': method({
    kashfMethodId: 'spiritual.p167.hiddenActionAirRows46815',
    kashfIntentId: 'spiritual.hiddenAction',
    topicId: 'spiritualDiagnostics',
    sourcePages: [167],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p167 hidden-action executor is wired. Take ONLY the AIR row of H4, H6, H8 and H15 (the balance/judge) and assemble one four-row figure. The printed question is personal: هل ورائي عمل — whether an action is behind the querent. Pure malefic => an action is behind the querent; every other source classification follows the explicit source complement “otherwise no”. This is covert/hidden action only and must never be promoted to sorcery, jinn, evil-eye or sorcerer identification.',
  }),

  // ── HOUSE 1 p166-170 intent boundaries ------------------------------
  'connection.p166-167.initiatorAndDegree': method({
    kashfMethodId: 'connection.p166-167.initiatorAndDegree',
    kashfIntentId: 'connection.specificPerson.initiatorAndDegree',
    topicId: 'generalReading',
    sourcePages: [166, 167],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Source-closed connection method for one specific person: water rows H4/H7/H13/H14, then combine with the balance; external/internal identifies who initiates movement, and element openness separately grades the connection. It is not a spiritual-diagnostics supporting check and has no approved public question route yet.',
  }),

  'need.p168-169.locationNameColorBalanceWalk': method({
    kashfMethodId: 'need.p168-169.locationNameColorBalanceWalk',
    kashfIntentId: 'need.locationNameColor',
    topicId: 'generalReading',
    sourcePages: [168, 169],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'The source requires walking the balance point to its endpoint, then a second figure for name/color derivation, but does not define the walking endpoint or second-figure selection sufficiently for computation. Do not infer these mechanics from symmetry or another book.',
  }),

  'matter.p169.validityH6H8Planet': method({
    kashfMethodId: 'matter.p169.validityH6H8Planet',
    kashfIntentId: 'matter.isRightForQuerent',
    topicId: 'generalReading',
    sourcePages: [169],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Exact intent: “is this matter right/valid for me?”. Combine H6+H8; Venus, Moon or Mercury figures mean yes, otherwise no. Current v57 wording loses the explicit Mercury/عطارد term, so this remains non-runnable until the Hebrew operational text is repaired and separately certified.',
  }),

  'need.p169-170.outcomeRules': method({
    kashfMethodId: 'need.p169-170.outcomeRules',
    kashfIntentId: 'need.fulfillment',
    topicId: 'generalReading',
    sourcePages: [169, 170],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'source-rule-set',
    executorStatus: 'pending',
    notes: 'Need-fulfillment rules are their own intent. The printed source separates the need-house quality, H10 angle/succedent/cadent timing, a derived water-house figure after completing H16, and the open-water-house check. Current v57 omits/shifts branches, so no aggregate runtime is authorized.',
  }),

  'attention.p170.mutualGazeFireRows1713': method({
    kashfMethodId: 'attention.p170.mutualGazeFireRows1713',
    kashfIntentId: 'attention.mutualGaze',
    topicId: 'marriage',
    sourcePages: [170],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'source-rule-set',
    executorStatus: 'pending',
    notes: 'p170 is a distinct gaze/attention rule with source conditions on fire rows H1/H7/H13. Current v57 omits a condition/result branch. It must not replace or vote against the separately selected p204 love-attention method used by q-who-looks-love.',
  }),

  'decision.external.p170-172.istikharaFigureTable': method({
    kashfMethodId: 'decision.external.p170-172.istikharaFigureTable',
    kashfIntentId: 'decision.istikharaByFigure',
    topicId: 'generalReading',
    sourcePages: [170, 171, 172],
    sourceLayer: 'quoted-alternate',
    attributedSourceBook: 'other-book',
    methodRole: 'external-tradition',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The book explicitly marks this istikhara table as خارج الكتاب / from outside the book. It remains searchable reference knowledge only. It must never auto-route, run in parallel with the selected Kashf body method, or vote against it.',
  }),

  'religion.p253.h3h9Quality': method({
    kashfMethodId: 'religion.p253.h3h9Quality',
    kashfIntentId: 'religion.religiosity',
    topicId: 'religion',
    sourcePages: [253],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical p253 religion/righteousness executor is wired. Both H3 and H9 pure malefic => little religion; both pure benefic => religious and God-fearing according to the source wording. Mixed figures and split H3/H9 testimony remain unresolved rather than being forced into a binary judgment. It does not answer broad theological, spiritual-practice or faith-advice questions.',
  }),

  'spiritual.jinnType.unsupported': method({
    kashfMethodId: 'spiritual.jinnType.unsupported',
    kashfIntentId: 'spiritual.jinnType',
    topicId: 'spiritualDiagnostics',
    sourcePages: [167],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited Kashf body method classifies an alleged influence as jinn vs evil eye vs human sorcery. p167 must not be stretched into this diagnosis.',
  }),

  'spiritual.sorcererIdentity.unsupported': method({
    kashfMethodId: 'spiritual.sorcererIdentity.unsupported',
    kashfIntentId: 'spiritual.sorcererIdentity',
    topicId: 'spiritualDiagnostics',
    sourcePages: [167],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p167 can ask whether the querent acts by sorcery on the quesited person; it does not identify a named sorcerer behind an alleged harm. No identity method is selected.',
  }),

  'spiritual.obsessionCause.unsupported': method({
    kashfMethodId: 'spiritual.obsessionCause.unsupported',
    kashfIntentId: 'spiritual.obsessionCause',
    topicId: 'spiritualDiagnostics',
    sourcePages: [43],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'House symbolism includes worry/waswasa-like meanings, but no audited operational Kashf body rule distinguishes spiritual from psychological causes of anxiety or intrusive thoughts. Do not diagnose by house meaning alone.',
  }),

  'security.external.p235.h8': method({
    kashfMethodId: 'security.external.p235.h8',
    kashfIntentId: 'security.general',
    topicId: 'deathInheritance',
    sourcePages: [235, 236],
    sourceLayer: 'added-from-other-book',
    attributedSourceBook: 'al-Multaqat',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The H8 security/fear/longevity/inheritance material is in the explicitly attributed collected/al-Multaqat addition. Keep it in educational knowledge only; never feed a Kashf body verdict.',
  }),

  'social.slander.unsupported': method({
    kashfMethodId: 'social.slander.unsupported',
    kashfIntentId: 'social.slander',
    topicId: 'enemies',
    sourcePages: [43],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Slander/backbiting can appear among house meanings, but no audited operational body-source method has been selected for the UI yes/no/identity question.',
  }),

  'social.twoFaced.unsupported': method({
    kashfMethodId: 'social.twoFaced.unsupported',
    kashfIntentId: 'social.twoFaced',
    topicId: 'enemies',
    sourcePages: [43],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited Kashf body method establishes that a specific person is two-faced/deceptive. General house symbolism is not an operational verdict.',
  }),

  'wronged.status.unsupported': method({
    kashfMethodId: 'wronged.status.unsupported',
    kashfIntentId: 'wronged.status',
    topicId: 'disputes',
    sourcePages: [43],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The wronged/oppressed person occurs in house meanings, but no audited operational Kashf body method has been selected for the broad UI question. Keep blocked rather than infer from house semantics.',
  }),

  'isolation.status.unsupported': method({
    kashfMethodId: 'isolation.status.unsupported',
    kashfIntentId: 'isolation.status',
    topicId: 'enemies',
    sourcePages: [43],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Isolation/confinement meanings of houses do not constitute a dedicated operational method for the broad UI isolation question.',
  }),

  // ── FINAL QUESTION-BANK COVERAGE slice -------------------------------
  'agriculture.mixedScope.unsupported': method({
    kashfMethodId: 'agriculture.mixedScope.unsupported',
    kashfIntentId: 'agriculture.mixedScope',
    topicId: 'yearlyForecast',
    sourcePages: [184, 222],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The UI mixes crop yield, irrigation and land ownership. Kashf body p184 treats land/property structure, while agriculture/yield material mapped at p222 belongs to the Nuzhat addition. Split the question before any operational method is selected.',
  }),

  'family.fatherPropertyMixedScope.unsupported': method({
    kashfMethodId: 'family.fatherPropertyMixedScope.unsupported',
    kashfIntentId: 'family.fatherPropertyMixedScope',
    topicId: 'parentsProperty',
    sourcePages: [184],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p184 contains distinct rules for father condition and for property/house/land. The current UI merges father health, house and land into one question, so it must be split rather than routed to one verdict.',
  }),

  'direction.generic.unsupported': method({
    kashfMethodId: 'direction.generic.unsupported',
    kashfIntentId: 'direction.generic',
    topicId: 'generalReading',
    sourcePages: [117, 188, 246],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Kashf contains several domain-specific direction systems with different provenance and inputs. No single body-source generic direction method is selected for every question.',
  }),

  'helpers.generic.unsupported': method({
    kashfMethodId: 'helpers.generic.unsupported',
    kashfIntentId: 'helpers.findHelp',
    topicId: 'completion',
    sourcePages: [176],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p176 contains servant/service material, but no audited canonical body method has been selected for the broad modern question “will I find someone to help me?”. Do not generalize servant rules automatically.',
  }),

  'illness.causeMixedScope.unsupported': method({
    kashfMethodId: 'illness.causeMixedScope.unsupported',
    kashfIntentId: 'illness.causeMixedScope',
    topicId: 'illness',
    sourcePages: [197],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p197 classifies humoral/elemental illness nature. It does not provide a verified modern physical-vs-emotional-vs-environmental cause classifier. Keep the broader cause question blocked.',
  }),

  'illness.p197.h1h8ElementHumor': method({
    kashfMethodId: 'illness.p197.h1h8ElementHumor',
    kashfIntentId: 'illness.humor',
    topicId: 'illness',
    sourcePages: [197],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'illness',
    notes: 'Source-scoped H1/H8 same-element humoral terminology only; mixed elements are unresolved, and this is not a modern medical diagnosis.',
  }),

  'money.loseFortune.unsupported': method({
    kashfMethodId: 'money.loseFortune.unsupported',
    kashfIntentId: 'money.loseFortune',
    topicId: 'money',
    sourcePages: [179, 223],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No single audited body-source canonical method is selected for the broad question of losing one’s fortune. p223 loss/profit material is in an added/Nuzhat context and is not a body fallback.',
  }),

  'nativity.birthDate.unsupported': method({
    kashfMethodId: 'nativity.birthDate.unsupported',
    kashfIntentId: 'nativity.birthDate',
    topicId: 'generalReading',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited Kashf canonical method has been selected for deriving a complete fate reading from a birth date alone.',
  }),

  'social.neighbor.unsupported': method({
    kashfMethodId: 'social.neighbor.unsupported',
    kashfIntentId: 'social.neighborState',
    topicId: 'siblings',
    sourcePages: [182],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The selected p182 siblings method is not automatically a neighbor method. No separate audited canonical rule for the broad neighbor question is selected.',
  }),

  'authority.officialDocs.unsupported': method({
    kashfMethodId: 'authority.officialDocs.unsupported',
    kashfIntentId: 'authority.officialDocs',
    topicId: 'authorityState',
    sourcePages: [256, 257],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The audited authority chapter covers honor, appointments, rulers and return to service. It does not provide a selected body-source method for modern visa/license/contract approval.',
  }),

  'general.pastEvents.unsupported': method({
    kashfMethodId: 'general.pastEvents.unsupported',
    kashfIntentId: 'general.pastEvents',
    topicId: 'generalReading',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited Kashf canonical method has been selected for reconstructing arbitrary past events from a generic question.',
  }),

  'family.relativeState.unsupported': method({
    kashfMethodId: 'family.relativeState.unsupported',
    kashfIntentId: 'family.relativeState',
    topicId: 'siblings',
    sourcePages: [182],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The canonical p182 sibling method is source-specific to siblings and must not be expanded to every in-law, uncle, relative or neighbor without an explicit source rule.',
  }),

  'separation.mixedScope.unsupported': method({
    kashfMethodId: 'separation.mixedScope.unsupported',
    kashfIntentId: 'separation.mixedScope',
    topicId: 'generalReading',
    sourcePages: [183, 211],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The current UI mixes separation from a person, a place and a relationship. Kashf has distinct relocation and marriage-dissolution methods; no universal separation method should be inferred.',
  }),

  'separation.loved.unsupported': method({
    kashfMethodId: 'separation.loved.unsupported',
    kashfIntentId: 'separation.lovedPerson',
    topicId: 'marriage',
    sourcePages: [205, 211, 264],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Love and marriage passages do not yield a selected universal canonical method for whether separation from a loved person is final. Do not substitute marriage divorce or friendship alternatives automatically.',
  }),

  'stalled.cause.unsupported': method({
    kashfMethodId: 'stalled.cause.unsupported',
    kashfIntentId: 'stalled.cause',
    topicId: 'generalReading',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited Kashf canonical method has been selected for diagnosing the general cause of “why is everything stuck?”. Keep this broad causal question blocked.',
  }),

  'stranger.description.unresolved': method({
    kashfMethodId: 'stranger.description.unresolved',
    kashfIntentId: 'stranger.description',
    topicId: 'generalReading',
    sourcePages: [68, 69, 71, 72, 74, 76, 77, 79, 81, 82, 85, 86, 88, 89, 91, 93],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Kashf contains detailed figure descriptions, but a source-safe operational rule selecting which figure/house describes an arbitrary unknown stranger has not been closed. Do not turn the descriptive corpus into a generic identity engine by inference.',
  }),

  // ── REPAIR REQUIRED ----------------------------------------------------
  'money.p180.elementComparison': method({
    kashfMethodId: 'money.p180.elementComparison',
    kashfIntentId: 'money.compareQuestionerAsked',
    topicId: 'money',
    sourcePages: [180],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p180 derives the queried-person money figure from H2/H4/H6/H8 and the querent money figure from H1/H3/H5/H7, then compares their elements using fire=1, air=2, water=3, earth=4. The final instruction says to keep the lower element and work by that number “so it is the money”, but it does not define a source-safe conversion from the retained element/number into a monetary amount. Runtime is therefore blocked. Do not substitute incoming/outgoing classification, a dignity table, the p182 lifespan-scale amount rule, or any external tradition.',
  }),

  'marriage.p205.modestyPurity': method({
    kashfMethodId: 'marriage.p205.modestyPurity',
    kashfIntentId: 'marriage.modesty',
    topicId: 'marriage',
    sourcePages: [205, 206],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    legacyTopicId: 'marriage',
    notes: 'Canonical source uses the explicit pure/impure figure classification, including H1/H7/H9 and the balance/judge conditions. Current code incorrectly substitutes benefic/malefic for pure/impure, so it must be repaired before runtime use.',
  }),

  'hope.p267.fulfillment': method({
    kashfMethodId: 'hope.p267.fulfillment',
    kashfIntentId: 'hope.fulfillment',
    topicId: 'friendsHope',
    sourcePages: [267],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Canonical hope method requires incoming conditions, H11 recurrence, nature matching and fallback; current count-quality implementation is not source-equivalent.',
  }),

  'dream.p254.h9AndTransit': method({
    kashfMethodId: 'dream.p254.h9AndTransit',
    kashfIntentId: 'dream.meaning',
    topicId: 'dream',
    sourcePages: [254],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'custom-engine',
    executorStatus: 'pending',
    notes: 'Must judge H9 and then where the H9 figure moved; current implementation is partial.',
  }),

  'friends.p263.h1h11': method({
    kashfMethodId: 'friends.p263.h1h11',
    kashfIntentId: 'friends.relationship',
    topicId: 'friendsHope',
    sourcePages: [263, 264],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'formula',
    executorStatus: 'pending',
    legacyTopicId: 'friendsHope',
    notes: 'Core friendship formula is usable only after removing unrelated hope/Nuzhat bundle execution.',
  }),

  'state.p265.h1h2h9h15': method({
    kashfMethodId: 'state.p265.h1h2h9h15',
    kashfIntentId: 'state.stability',
    topicId: 'authorityState',
    sourcePages: [265],
    kashfRuntimeStatus: 'repair-required',
    runtimeAllowed: false,
    executionKind: 'legacy-function',
    executorStatus: 'pending',
    legacyTopicId: 'authorityState',
    notes: 'Existing helper must be isolated from the authorityState topic bundle.',
  }),

  'missing.p248-249.lifeH1H4H9Outcome': method({
    kashfMethodId: 'missing.p248-249.lifeH1H4H9Outcome',
    kashfIntentId: 'missing.aliveOrDead',
    topicId: 'missingPerson',
    sourcePages: [248, 249],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    notes: 'Canonical pp248-249 missing-person life-status executor is wired from the original-scan provenance. H1+H15+H4+H9 all pure benefic expose the explicit alive sign. H6+H7+H8+H15 all drawn from the exact five named figures — קהלה, חיבור, דרך, לבן, אדום — expose the separate death testimony. סוהר ושפל ראש belong to a neighboring rule and are excluded. Neither absence of the alive sign nor the named-figure condition is inverted into the opposite verdict.',
  }),

  'enemy.p271.h1vsH12': method({
    kashfMethodId: 'enemy.p271.h1vsH12',
    kashfIntentId: 'enemy.presenceAndDominance',
    topicId: 'enemies',
    sourcePages: [271],
    kashfRuntimeStatus: 'ready',
    runtimeAllowed: true,
    executionKind: 'custom-engine',
    executorStatus: 'ready',
    legacyTopicId: 'enemies',
    notes: 'Source-scoped four-case H1/H12 rule; mixed quality remains unresolved. No person is identified and legacy primary combine(1,12) is bypassed.',
  }),

  // ── BLOCKED BY SOURCE --------------------------------------------------
  'relocation.p183.compare12vs78': method({
    kashfMethodId: 'relocation.p183.compare12vs78',
    kashfIntentId: 'relocation.compareTwoCities',
    topicId: 'relocation',
    sourcePages: [183],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p183 asks which of two cities is better, first requires benefic figures, then inspects H1/H2/H7/H8/H9 and the outcome: if H1+H2 are stronger the current place is better; if H7+H8 are stronger the move is better. The passage does not define an operational strength metric or how H9/outcome participates in that comparison. Preserve the benefic precondition and all named houses, but do not invent a strength score from dignity, element, recurrence, Hawi, or the legacy topic bundle.',
  }),

  'relocation.p184.multiIndicatorStayMove': method({
    kashfMethodId: 'relocation.p184.multiIndicatorStayMove',
    kashfIntentId: 'relocation.p184SupportingIndicators',
    topicId: 'relocation',
    sourcePages: [184],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed p184 gives several additional relocation indicators: benefic testimony through H6/H7 supports staying in the current place; benefic H1/H12 supports moving to the desired place; an internal figure in H2 supports staying. The passage gives no precedence or conflict-resolution rule when these indicators disagree. Keep this as a distinct source procedure and never aggregate, vote, or use it as a fallback for the selected p183 route.',
  }),

  'property.p184-185.houseGardenMap': method({
    kashfMethodId: 'property.p184-185.houseGardenMap',
    kashfIntentId: 'property.houseGardenCondition',
    topicId: 'property',
    sourcePages: [184, 185],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: 'source-procedure',
    executorStatus: 'pending',
    notes: 'Printed pp184-185 map H4=land/ground, H10=trees, H7=vegetables/plants (البقول), H3=water channels (السواقي), and H2=the surrounding wall. Benefics in a mapped place are judged good and malefics the opposite, but the continuation says reliance is on “the witnesses” without defining which witness system applies here. The H7/H3 mapping is fixed from the printed source; runtime remains blocked until the applicable witness system is source-certified. Do not borrow a witness scheme from another chapter or infer one by symmetry.',
  }),

  'gift.sourceInputUnclear': method({
    kashfMethodId: 'gift.sourceInputUnclear',
    kashfIntentId: 'gift.receive',
    topicId: 'children',
    sourcePages: [193],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Gift verdict polarity is stated, but the exact house/input to which it applies is not sufficiently explicit.',
  }),

  'pregnancy.miscarriageRisk.unresolved': method({
    kashfMethodId: 'pregnancy.miscarriageRisk.unresolved',
    kashfIntentId: 'pregnancy.miscarriageRiskLegacyPlaceholder',
    topicId: 'children',
    sourcePages: [192, 193],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Compatibility placeholder from before Batch21. q-miscarriage no longer routes here. The selected canonical route is the exact p191-192 Humra-H7 + Nakis-H8 cross-page rule; other p192-p193 risk branches remain separate and do not aggregate.',
  }),

  'child.lifespan.p195.provenanceUnresolved': method({
    kashfMethodId: 'child.lifespan.p195.provenanceUnresolved',
    kashfIntentId: 'child.lifespan',
    topicId: 'children',
    sourcePages: [195],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p195 contains child-lifespan material adjacent to al-Zanati material. Passage-level provenance must be closed before this can be selected operationally.',
  }),

  'marriage.p207-208.adulterySignsUnresolved': method({
    kashfMethodId: 'marriage.p207-208.adulterySignsUnresolved',
    kashfIntentId: 'marriage.adulterySigns',
    topicId: 'marriage',
    sourcePages: [207, 208],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The body text supplies specific warning signs associated with sexual misconduct or another attachment, but the audited passage does not provide a complete symmetric yes/no method for all figures. Do not turn partial signs into a universal adultery verdict.',
  }),

  'travel.p242.vehicleSafety': method({
    kashfMethodId: 'travel.p242.vehicleSafety',
    kashfIntentId: 'travel.vehicleSafety',
    topicId: 'travel',
    sourcePages: [242],
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Source contradiction: house 12 appears in conflicting outcome groups. No code until textual resolution.',
  }),

  'prisoner.releaseTiming.unresolved': method({
    kashfMethodId: 'prisoner.releaseTiming.unresolved',
    kashfIntentId: 'prisoner.releaseTiming',
    topicId: 'prisoner',
    sourcePages: [272, 273],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'blocked-by-source',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No canonical body method selected that yields release timing. Do not infer timing from outcome/exit rules.',
  }),

  // ── EDUCATIONAL / EXTERNAL --------------------------------------------
  'promise.external.p255': method({
    kashfMethodId: 'promise.external.p255',
    kashfIntentId: 'promise.fulfillment',
    topicId: 'completion',
    sourcePages: [255],
    sourceLayer: 'added-from-other-book',
    attributedSourceBook: 'Nuzhat al-Uqul',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: 'legacy-function',
    executorStatus: 'not-applicable',
    notes: 'Knowledge-only. Must never feed verdict.',
  }),

  'yearly.external.p221-223': method({
    kashfMethodId: 'yearly.external.p221-223',
    kashfIntentId: 'yearly.forecast',
    topicId: 'yearlyForecast',
    sourcePages: [221, 222, 223],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Mapped material in this range belongs to non-body/Nuzhat additions; retained for learning only by default.',
  }),

  'fear.external.p274.h7h8': method({
    kashfMethodId: 'fear.external.p274.h7h8',
    kashfIntentId: 'fear.general',
    topicId: 'fear',
    sourcePages: [274],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: 'formula',
    executorStatus: 'not-applicable',
    notes: 'Post-ومن غير الكتاب material; knowledge-only by default.',
  }),

  'commerce.external.p218.buySell': method({
    kashfMethodId: 'commerce.external.p218.buySell',
    kashfIntentId: 'commerce.buySell',
    topicId: 'commerce',
    sourcePages: [218],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The buy/sell rule begins after an explicit ومن غير الكتاب marker. Knowledge-only by default.',
  }),

  'market.external.p218-223.price': method({
    kashfMethodId: 'market.external.p218-223.price',
    kashfIntentId: 'market.price',
    topicId: 'yearlyForecast',
    sourcePages: [218, 221, 222, 223],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Price/dearness-cheapness material in this range belongs to non-body and Nuzhat additions. It remains educational and must not feed the live verdict.',
  }),

  'loan.external.p234.repayment': method({
    kashfMethodId: 'loan.external.p234.repayment',
    kashfIntentId: 'loan.repayment',
    topicId: 'loan',
    sourcePages: [234],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The p234 loan chain lies inside the non-body block that starts at p228. Keep for learning only by default.',
  }),

  'loan.external.p234.shouldGive': method({
    kashfMethodId: 'loan.external.p234.shouldGive',
    kashfIntentId: 'loan.shouldGive',
    topicId: 'loan',
    sourcePages: [234],
    sourceLayer: 'non-body-addition',
    attributedSourceBook: 'other',
    methodRole: 'educational-only',
    kashfRuntimeStatus: 'educational-only',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The p234 “is this loan sound / should it be given” rule is non-body material. Knowledge-only by default.',
  }),

  // ── UNSUPPORTED / ABSTRACT INTENTS ------------------------------------
  'hidden.abstractSecret.unsupported': method({
    kashfMethodId: 'hidden.abstractSecret.unsupported',
    kashfIntentId: 'hidden.abstractSecret',
    topicId: 'hiddenTreasure',
    sourcePages: [184, 188],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The audited body rules address physical hidden things/locations. They do not provide a verified canonical method for “what secret/truth is being hidden?”.',
  }),

  // Compatibility placeholder retained for historical route references only.
  'money.lawfulness.unsupported': method({
    kashfMethodId: 'money.lawfulness.unsupported',
    kashfIntentId: 'money.lawfulness',
    topicId: 'money',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Audited p179-p182 money chapter did not yield an explicit body-source lawful/unlawful money method. Do not revive the previously assumed H9+H11 rule without a source passage.',
  }),

  'debt.outcome.unsupported': method({
    kashfMethodId: 'debt.outcome.unsupported',
    kashfIntentId: 'debt.outcome',
    topicId: 'loan',
    sourcePages: [179],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'p179 contains a financial-claim passage, but no single canonical body method has been selected for the broad UI question “old debt — what will happen?”. Keep blocked rather than generalize.',
  }),

  'property.sale.unsupported': method({
    kashfMethodId: 'property.sale.unsupported',
    kashfIntentId: 'property.sale',
    topicId: 'commerce',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'No audited body-source canonical method has been selected for whether a specific property will sell. Do not fall back to non-body commerce rules.',
  }),

  'money.missingMixedScope.unsupported': method({
    kashfMethodId: 'money.missingMixedScope.unsupported',
    kashfIntentId: 'money.missingMixedScope',
    topicId: 'money',
    sourcePages: [],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'The current UI mixes physically lost money, theft, unpaid debt and failed investment. These are different intents and must be split before any Kashf method is selected.',
  }),

  // ── LEGACY UNSUPPORTED PLACEHOLDER (kept only for old P0 route history) -
  'spiritual.affectedBySorcery.unsupported': method({
    kashfMethodId: 'spiritual.affectedBySorcery.unsupported',
    kashfIntentId: 'spiritual.affectedBySorcery',
    topicId: 'spiritualDiagnostics',
    sourcePages: [167],
    methodRole: 'unresolved',
    kashfRuntimeStatus: 'unsupported',
    runtimeAllowed: false,
    executionKind: null,
    executorStatus: 'not-applicable',
    notes: 'Compatibility placeholder only. p167 asks whether the querent acts by sorcery on the quesited person; it does not answer whether the querent is affected by sorcery/evil eye/jinn.',
  }),
});

export function getKashfMethod(kashfMethodId) {
  return KASHF_CANONICAL_METHODS[kashfMethodId] || null;
}

export function getKashfMethodsForIntent(kashfIntentId) {
  return Object.values(KASHF_CANONICAL_METHODS)
    .filter((entry) => entry.kashfIntentId === kashfIntentId);
}

export function getCanonicalKashfMethodForIntent(kashfIntentId) {
  const matches = getKashfMethodsForIntent(kashfIntentId)
    .filter((entry) => entry.methodRole === 'canonical-operational');
  return matches.length === 1 ? matches[0] : null;
}

export function canRunKashfMethod(kashfMethodId) {
  const entry = getKashfMethod(kashfMethodId);
  return !!entry
    && entry.methodRole === 'canonical-operational'
    && entry.kashfRuntimeStatus === 'ready'
    && entry.executorStatus === 'ready'
    && entry.runtimeAllowed === true;
}

export function validateKashfMethodRegistry() {
  const errors = [];
  const seenIds = new Set();
  const canonicalByIntent = new Map();

  for (const [key, entry] of Object.entries(KASHF_CANONICAL_METHODS)) {
    if (!entry || typeof entry !== 'object') {
      errors.push(`${key}: method entry must be an object`);
      continue;
    }
    if (entry.kashfMethodId !== key) errors.push(`${key}: key must equal kashfMethodId`);
    if (seenIds.has(entry.kashfMethodId)) errors.push(`${key}: duplicate kashfMethodId`);
    seenIds.add(entry.kashfMethodId);

    if (!entry.kashfIntentId) errors.push(`${key}: kashfIntentId is required`);
    if (!KASHF_RUNTIME_STATUSES.includes(entry.kashfRuntimeStatus)) {
      errors.push(`${key}: invalid kashfRuntimeStatus ${entry.kashfRuntimeStatus}`);
    }
    if (!KASHF_METHOD_ROLES.includes(entry.methodRole)) {
      errors.push(`${key}: invalid methodRole ${entry.methodRole}`);
    }
    if (!KASHF_EXECUTOR_STATUSES.includes(entry.executorStatus)) {
      errors.push(`${key}: invalid executorStatus ${entry.executorStatus}`);
    }
    if (entry.runtimeAllowed && entry.kashfRuntimeStatus !== 'ready') {
      errors.push(`${key}: runtimeAllowed=true requires status=ready`);
    }
    if (entry.runtimeAllowed && entry.methodRole !== 'canonical-operational') {
      errors.push(`${key}: runtimeAllowed=true requires canonical-operational role`);
    }
    if (entry.runtimeAllowed && entry.executorStatus !== 'ready') {
      errors.push(`${key}: runtimeAllowed=true requires executorStatus=ready`);
    }
    if (entry.runtimeAllowed && (entry.attributedSourceBook !== 'Kashf' || entry.sourceLayer !== 'body')) {
      errors.push(`${key}: attributed/external methods are reference-only and cannot be runtimeAllowed`);
    }

    if (entry.methodRole === 'canonical-operational') {
      const existing = canonicalByIntent.get(entry.kashfIntentId);
      if (existing) {
        errors.push(`${entry.kashfIntentId}: more than one canonical-operational method (${existing}, ${entry.kashfMethodId})`);
      } else {
        canonicalByIntent.set(entry.kashfIntentId, entry.kashfMethodId);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

export default {
  KASHF_RUNTIME_STATUSES,
  KASHF_METHOD_ROLES,
  KASHF_EXECUTOR_STATUSES,
  KASHF_CANONICAL_METHODS,
  getKashfMethod,
  getKashfMethodsForIntent,
  getCanonicalKashfMethodForIntent,
  canRunKashfMethod,
  validateKashfMethodRegistry,
};
