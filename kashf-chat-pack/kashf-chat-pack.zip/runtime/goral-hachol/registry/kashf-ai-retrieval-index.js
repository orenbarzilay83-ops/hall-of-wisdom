/**
 * kashf-ai-retrieval-index.js
 *
 * Machine-facing retrieval index for the Hebrew Kashf v57 knowledge layer.
 *
 * Why this exists:
 * - kashf-v57-topic-index.html is an excellent human/page navigation index,
 *   but it is chapter/page oriented.
 * - The AI needs method-level retrieval: user wording -> exact intent -> exact
 *   canonical method -> exact v57 page(s) -> runtime status.
 * - This module derives its records from the canonical registries so the AI
 *   index cannot silently drift away from routing/runtime truth.
 *
 * Source policy:
 * - v57 Hebrew is operational-primary.
 * - Arabic remains verification-only.
 * - Retrieval NEVER changes runtimeAllowed/executorStatus.
 * - A good retrieval hit does not authorize execution of a blocked/pending
 *   method.
 */

import { KASHF_CANONICAL_METHODS } from './kashf-canonical-method-registry.js';
import { KASHF_QUESTION_ROUTES } from './kashf-question-route-registry.js';
import { KASHF_V57_KNOWLEDGE } from './kashf-v57-knowledge-registry.js';

const HEBREW_DIACRITICS_RE = /[\u0591-\u05C7]/g;
const PUNCT_RE = /[\u05BE\u05F3\u05F4'"״׳,:;.!?()\[\]{}\/\\|+*=<>—–_-]+/g;

const STOPWORDS = new Set([
  'האם', 'מה', 'מי', 'איך', 'כיצד', 'למה', 'מדוע', 'של', 'את', 'על', 'עם',
  'אל', 'מן', 'מ', 'ב', 'ל', 'כ', 'ו', 'או', 'גם', 'זה', 'זו', 'זאת', 'הוא',
  'היא', 'הם', 'הן', 'יש', 'אין', 'יהיה', 'תהיה', 'אני', 'לי', 'לו', 'לה',
  'אותו', 'אותה', 'אדם', 'איש', 'אישה', 'דבר', 'עניין',
]);

/**
 * Curated natural-language aliases for intents that already matter to the
 * canonical app flow. These aliases are retrieval hints only; they are never
 * executable rules.
 */
const RETRIEVAL_OVERRIDES = Object.freeze({
  'pregnancy.p191.existsH5SilentEmpty': {
    aliases: ['האם יש הריון', 'האם ההריון קיים', 'האם ההריון נכון', 'האם היא בהריון', 'קיום הריון', 'H5 שותקת ריקה הריון', 'פתיחת דין הריון עמ 191'],
    doNotMixWith: ['pregnancy.p191.genderH5', 'pregnancy.p191.childSafetyH1H6H8', 'pregnancy.p191.deliveryDifficultyH1H5H15', 'pregnancy.p191-192.miscarriageRedH7NakisH8', 'pregnancy.p192.maternalSafetyH6H8H12', 'pregnancy.p192.monthCount'],
    houses: [5],
  },
  'pregnancy.p191.genderH5': {
    aliases: ['זכר או נקבה', 'מין הוולד', 'בן או בת', 'זכר או נקבה בהריון', 'מה מין התינוק', 'מין הוולד לפי H5', 'צורה זכרית נקבית בית חמישי', 'מין העובר עמ 191'],
    doNotMixWith: ['pregnancy.p192.genderH5H11InOut', 'pregnancy.p192.genderParityH1H6H8H12', 'pregnancy.p191.existsH5SilentEmpty', 'pregnancy.p191.childSafetyH1H6H8', 'pregnancy.p191.deliveryDifficultyH1H5H15'],
    houses: [5],
  },
  'pregnancy.p191.twinsMujassad': {
    aliases: ['האם תאומים', 'مجسدا תאומים', 'סימן תאומים עמ 191'],
    doNotMixWith: ['pregnancy.p191.genderH5', 'pregnancy.p191.deliveryDifficultyH1H5H15'],
    houses: [5],
  },
  'pregnancy.p191-192.miscarriageRedH7NakisH8': {
    aliases: ['חשש להפלה', 'אדום בבית 7 שפל ראש בבית 8', 'חמרה שביעי אנכיס שמיני', 'סימן הפלה עמ 191 192'],
    doNotMixWith: ['pregnancy.p191.childSafetyH1H6H8', 'pregnancy.p192.maternalSafetyH6H8H12', 'pregnancy.p191.existsH5SilentEmpty'],
    houses: [7, 8],
  },
  'pregnancy.p192.genderH5H11InOut': {
    aliases: ['מין הוולד H5 H11 פנימי חיצוני', 'מיטיבים חיצוניים חמישי אחד עשר זכר', 'מיטיבים פנימיים חמישי אחד עשר נקבה'],
    doNotMixWith: ['pregnancy.p191.genderH5', 'pregnancy.p192.genderParityH1H6H8H12'],
    houses: [5, 11],
  },
  'pregnancy.p192.genderParityH1H6H8H12': {
    aliases: ['מין הוולד זוג פרד H1 H6 H8 H12', 'תוצאה יחידית זכר זוגית נקבה עמ 192'],
    doNotMixWith: ['pregnancy.p191.genderH5', 'pregnancy.p192.genderH5H11InOut'],
    houses: [1, 6, 8, 12],
  },
  'pregnancy.p192.maternalSafetyH6H8H12': {
    aliases: ['בטיחות היולדת', 'האם האם בטוחה בלידה', 'H6 H8 H12 מיטיבים יולדת'],
    doNotMixWith: ['pregnancy.p191.childSafetyH1H6H8', 'pregnancy.p191-192.miscarriageRedH7NakisH8'],
    houses: [6, 8, 12],
  },
  'pregnancy.p192.monthCount': {
    aliases: ['כמה חודשי הריון', 'מניין חודשי ההריון', 'הפחת תשע תשע חודשי הריון', 'צורת המאזן מספר החודשים'],
    doNotMixWith: ['pregnancy.p191.existsH5SilentEmpty', 'pregnancy.p191.genderH5'],
    houses: [],
  },
  'pregnancy.p191.deliveryDifficultyH1H5H15': {
    aliases: ['לידה קלה או קשה', 'האם הלידה תהיה קלה', 'האם הלידה תהיה קשה', 'קלות וקושי הלידה'],
    doNotMixWith: ['pregnancy.p191.existsH5SilentEmpty', 'pregnancy.p191.genderH5', 'pregnancy.p191.childSafetyH1H6H8', 'pregnancy.p194.deliveryH5Weight', 'pregnancy.p192.maternalSafetyH6H8H12'],
    houses: [1, 5, 15],
  },
  'debt.p179.creditorDebtorWalking': {
    aliases: ['האם החייב יחזיר את הכסף', 'האם החוב יוחזר', 'תביעת חוב בין נושה לחייב', 'בעל החוב והחייב עמ 179'],
    doNotMixWith: ['loan.external.p234.repayment', 'debt.outcome.unsupported', 'money.p181.recast25811'],
    houses: [1, 2, 7, 9, 12],
  },
  'money.p180.elementComparison': {
    aliases: ['השוואת ממון השואל והנשאל', 'למי יש יותר ממון לפי היסודות', 'ממון הנשאל מול ממון השואל', 'יסוד תחתון סכום הממון עמ 180'],
    doNotMixWith: ['money.p182.h2h10Outlook', 'money.p180.livelihoodH10Invert', 'money.p181.recast25811', 'money.p179.sourceByIncomingHonorHouse'],
    houses: [1, 2, 3, 4, 5, 6, 7, 8],
  },
  'money.p181.otherBookRemainder': {
    aliases: ['מן ספר אחר שארית הממון', 'שארית שתיים ממון רב', 'טבלת 1 עד 7 מקור הממון', 'שיטת השארית החיצונית עמ 181'],
    doNotMixWith: ['money.p181.recast25811', 'money.p179.sourceByIncomingHonorHouse'],
    houses: [],
  },
  'money.p182.h2h10Outlook': {
    aliases: ['מה מצב הממון', 'מצב הכסף כרגע', 'בית הממון והפרנסה', 'מצב ממוני הכללי', 'דין H2 H10 לממון'],
    doNotMixWith: ['money.p180.elementComparison', 'money.p180.livelihoodH10Invert', 'money.p181.recast25811', 'money.p179.sourceByIncomingHonorHouse', 'money.p182.lawfulnessInclination'],
    houses: [2, 10],
  },
  'money.p182.lawfulnessInclination': {
    aliases: ['האם הממון מותר או אסור', 'האם הכסף כשר', 'ממון חלאל או חראם', 'חוקיות הממון לפי בית תשע ואחת עשרה'],
    doNotMixWith: ['money.p182.h2h10Outlook', 'money.p179.sourceByIncomingHonorHouse'],
    houses: [9, 11],
  },
  'money.p180.livelihoodH10Invert': {
    aliases: ['מה מצב הפרנסה', 'האם הפרנסה תתרחב', 'מצב המחיה', 'התרחבות הפרנסה', 'דין הפרנסה השוטפת'],
    doNotMixWith: ['money.p179.sourceByIncomingHonorHouse', 'money.p181.recast25811', 'inheritance.p180.elementComposite'],
    houses: [1,2,3,4,5,6,7,8,9,10,11,12],
  },
  'money.p181.recast25811': {
    aliases: ['האם הממון יושג', 'האם הכסף יגיע לידי', 'השגת ממון', 'האם אקבל את הכסף', 'ממון צפוי'],
    doNotMixWith: ['money.p179.sourceByIncomingHonorHouse', 'money.p180.livelihoodH10Invert', 'inheritance.p180.elementComposite'],
    houses: [2, 5, 8, 11],
  },
  'career.p266.returnToOffice': {
    aliases: ['האם אחזור לתפקיד', 'האם יחזור לתפקידו', 'חזרה למשרה לאחר הדחה', 'האם אשוב למקום העבודה', 'מי שהודח משירות האם יחזור'],
    doNotMixWith: ['state.p265.h1h2h9h15', 'authority.p257.appointmentH1H10Planet', 'authority.p256.honorConditionH10Planet'],
    houses: [1, 4, 7, 10, 16],
  },
  'missing.p248-249.lifeH1H4H9Outcome': {
    aliases: ['הנעדר חי או מת', 'האם הנעדר חי', 'מצב חייו של הנעדר', 'האם הנעדר בחיים'],
    doNotMixWith: ['missing.p249.returnAnglesJudge', 'missing.p249.locationDirectionUnresolved', 'travel.p244.returnH1H2H9'],
    houses: [1,4,6,7,8,9,15],
  },
  'child.p194.existenceH1H5Nature': {
    aliases: ['עצם הוולד H1 H5 טבע', 'התאמת טבע ראשון חמישי ילד', 'לא זכר ולא נקבה מתהפכת בטן ריקה'],
    doNotMixWith: ['child.p194.healthTrajectoryH6H8', 'pregnancy.p191.existsH5SilentEmpty'],
    houses: [1, 5],
  },
  'child.p194.wellbeingH5H16': {
    aliases: ['מזל הילד H5 H16', 'מצב הילד וממונו', 'חמישי ושישה עשר מיטיבים ילד'],
    doNotMixWith: ['child.p194.healthTrajectoryH6H8', 'illness.p196.outcomeH15'],
    houses: [5, 16],
  },
  'pregnancy.p194.deliveryH5Weight': {
    aliases: ['H5 כבדה לידה כבדה', 'H5 מיטיבה לידה קלה עמ 194', 'כובד הלידה בית חמישי'],
    doNotMixWith: ['pregnancy.p191.deliveryDifficultyH1H5H15'],
    houses: [5],
  },
  'child.p194.healthTrajectoryH6H8': {
    aliases: ['בריאות הילד לאורך הזמן', 'בריאות הילד כשיגדל', 'מכאובים בילדות ובריאות בהמשך', 'מצב בריאות הילד לאורך השנים'],
    doNotMixWith: ['pregnancy.p191.childSafetyH1H6H8', 'illness.p196.outcomeH15', 'child.p194.existenceH1H5Nature', 'child.p194.wellbeingH5H16', 'pregnancy.p194.deliveryH5Weight'],
    houses: [6, 8],
  },
  'illness.p196.h1RecurrenceDurationRisk': {
    aliases: ['H1 בשישי המחלה מתארכת', 'H1 בשמיני מחלה סכנה', 'משך המחלה עמ 196'],
    doNotMixWith: ['illness.p196.outcomeH15', 'illness.p196.sensorySignsH6H8', 'illness.p197.h1h8ElementHumor'],
    houses: [1, 6, 8],
  },
  'illness.p196.sensorySignsH6H8': {
    aliases: ['אחיאן H8 עיוורון H6 חושך ראייה', 'שבתאי צדק H6 H8 כובד שמיעה', 'סימני ראייה שמיעה עמ 196'],
    doNotMixWith: ['illness.p196.outcomeH15', 'illness.p196.h1RecurrenceDurationRisk'],
    houses: [6, 8],
  },
  'illness.p196.outcomeH15': {
    aliases: ['האם החולה יחלים', 'האם יתרפא', 'החלמה ממחלה', 'האם המחלה תתארך', 'תוצאת החולי', 'H15 מיטיב יתרפא', 'H15 מזיק המחלה תתארך', 'תוצאת החולי עמ 196'],
    doNotMixWith: ['illness.p196.h1RecurrenceDurationRisk', 'illness.p196.sensorySignsH6H8', 'illness.bodyPart.h6Figure', 'illness.p197.h1h8ElementHumor'],
    houses: [15],
  },
  'siblings.p182.seniority': {
    aliases: ['מי הגדול בין האחים', 'מי הבכור בין האחים', 'סימן לאחים גדולים', 'מי הראשי בין האחים'],
    doNotMixWith: ['siblings.p182.h1h3'],
    houses: [3],
  },
  'love.p205.directLoveH1PlacementH15': {
    aliases: ['האם הוא אוהב אותי', 'האם אדם זה אוהב אותי', 'האם הוא אוהב אותך', 'אהבה ישירה', 'האם יש לו רצון בי'],
    doNotMixWith: ['love.p204.attentionFireRows1713', 'love.p206.womanFavorH7H11ThenH5', 'marriage.p211.dissolutionH7StateMatrix'],
    houses: [1, 15],
  },
  'marriage.p211.dissolutionH7StateMatrix': {
    aliases: ['האם תהיה פרידה בנישואין', 'האם הזוג יתגרש', 'יציבות הנישואין', 'פירוק הנישואין', 'האם הנישואין יישארו קיימים'],
    doNotMixWith: ['marriage.p210.generalMarriageH1H2H7H8H10Judge', 'love.p205.directLoveH1PlacementH15'],
    houses: [7],
  },
  'missing.p249.returnAnglesJudge': {
    aliases: ['האם הנעדר יחזור', 'האם הנעדר ישוב', 'חזרת הנעדר', 'האם הבורח יחזור'],
    doNotMixWith: ['travel.p244.returnH1H2H9', 'missing.p248-249.lifeH1H4H9Outcome', 'missing.p249.locationDirectionUnresolved'],
    houses: [1, 4, 7, 10, 15],
  },
  'pregnancy.p191.childSafetyH1H6H8': {
    aliases: ['האם הוולד יהיה בשלום', 'האם יש חשש לוולד', 'מה מצב שלום הוולד', 'האם הוולד יחיה', 'בטיחות הוולד'],
    doNotMixWith: ['pregnancy.p191.existsH5SilentEmpty', 'pregnancy.p191.genderH5', 'pregnancy.p191.deliveryDifficultyH1H5H15', 'pregnancy.p191-192.miscarriageRedH7NakisH8', 'pregnancy.p192.maternalSafetyH6H8H12', 'child.p194.healthTrajectoryH6H8'],
    houses: [1, 6, 8],
  },
  'lifespan.p264.stagesH11H9H7': {
    aliases: ['שלבי החיים', 'ראשית אמצע וסוף החיים', 'איך יהיו שלבי החיים', 'ילדות בגרות זקנה', 'מה מצב שלבי החיים'],
    doNotMixWith: ['lifespan.p178.elementCountToHouse', 'general.p174.h1h2h4h7h10h15'],
    houses: [11, 9, 7],
  },
  'travel.p244.returnH1H2H9': {
    aliases: ['האם הנוסע יחזור', 'האם ישוב מהמסע', 'חזרת הנוסע', 'האם יחזור הביתה מהנסיעה', 'האם ישוב לארצו'],
    doNotMixWith: ['travel.p238.assemble1359', 'travel.p238.timeSelectionH9H4', 'missing.p249.returnAnglesJudge'],
    houses: [1, 2, 9],
  },
  'marriage.p210.generalMarriageH1H2H7H8H10Judge': {
    aliases: ['האם השידוך מתאים', 'האם הזוגיות מתאימה', 'מה יהיה בנישואין', 'התאמת נישואין', 'סיכויי הנישואין'],
    doNotMixWith: ['marriage.p204.previousStatusH7inH10', 'marriage.p204.dowryH8', 'marriage.p211.dissolutionH7StateMatrix', 'love.p206.womanFavorH7H11ThenH5', 'desire.p206.querentWantsH7H11ThenH5'],
    houses: [1, 2, 5, 7, 8, 10, 15],
  },
  'dhamir.p159.subjectByH6Recurrence': {
    aliases: [
      'על מי השואל שואל',
      'על מי באמת נשאל',
      'על מי נסובה השאלה',
      'מי האדם שעליו השואל שואל',
      'איזה בעל בית הוא נושא השאלה',
      'זיהוי נושא השאלה לפי בית שש',
    ],
    doNotMixWith: [
      'general.p174.h1h2h4h7h10h15',
      'desire.p206.querentWantsH7H11ThenH5',
      'spiritual.p167.hiddenActionAirRows46815',
    ],
    houses: [6],
  },
  'general.p174.h1h2h4h7h10h15': {
    aliases: ['מה מצבי הכללי', 'מצב כללי', 'מה מצבו הכללי', 'סקירה כללית', 'כלל ענייניו של השואל', 'מה המצב הכללי שלי'],
    doNotMixWith: ['matter.p172.h17_h1011_thenCombine', 'completion.p173.fireRows15910', 'lifespan.p178.elementCountToHouse', 'lifespan.p264.stagesH11H9H7'],
    houses: [1, 2, 4, 7, 10, 15],
  },
  'completion.p173.fireRows15910': {
    aliases: ['האם העניין יושלם', 'האם הדבר יצליח', 'האם אצליח', 'השלמת העניין', 'הצלחת העניין'],
    doNotMixWith: ['matter.p172.h17_h1011_thenCombine'],
    houses: [1, 5, 9, 10],
  },
  'matter.p172.locationH2H16': {
    aliases: ['באיזה בית ענייני ורווחי', 'היכן מצוי עניינו של השואל', 'בית העניין והקניין'],
    doNotMixWith: ['matter.p172.h17_h1011_thenCombine', 'money.p179.sourceByIncomingHonorHouse'],
    houses: [2, 16],
  },
  'friend.p173.uniqueTariqBalance': {
    aliases: ['האם הידיד אוהב אותי לפי דרך במאזן', 'דרך יחידה במאזן ידיד', 'האם הידיד פונה לאחר'],
    doNotMixWith: ['love.p205.directLoveH1PlacementH15', 'love.p204.attentionFireRows1713'],
    houses: [7, 15],
  },
  'hope.p174.h5h11ThroughH1': {
    aliases: ['האם התקווה תתקיים לפי בתים חמש ואחת עשרה', 'תקווה לפי H5 H11 H1', 'בקשה תתקיים לפי שתי צורות ביניים'],
    doNotMixWith: ['completion.p173.fireRows15910', 'hope.p267.fulfillment'],
    houses: [1, 5, 11],
  },
  'authority.p175-176.needBeforeRulerChain': {
    aliases: ['צורך אצל השלטון', 'בקשה מבעל סמכות לפי בית ראשון ועשירי', 'צורך לפני שליט'],
    doNotMixWith: ['authority.p256.honorConditionH10Planet', 'authority.p257.rulerConditionH7H10', 'authority.p257.appointmentH1H10Planet'],
    houses: [1, 2, 6, 8, 10, 11, 12],
  },
  'request.p176.h1h2GateThenH1H4': {
    aliases: ['קיום בקשה לפי ראשון שני ורביעי', 'האם לעזוב את הבקשה', 'אחרית הבקשה H1 H2 H4'],
    doNotMixWith: ['completion.p173.fireRows15910', 'hope.p174.h5h11ThroughH1', 'hope.p267.fulfillment'],
    houses: [1, 2, 4],
  },
  'intent.p176.h7h10': {
    aliases: ['כוונת אדם לפי בית שבע ועשר', 'מה כוונת האדם H7 H10', 'כוונה טובה או רעה לפי 7 ו 10'],
    doNotMixWith: ['dhamir.p159.subjectByH6Recurrence'],
    houses: [7, 10],
  },
  'meeting.p176.hopeHouseH1H13': {
    aliases: ['האם אפגוש את האדם המבוקש', 'מפגש עם המבוקש לפי H1 H13', 'בית התקווה בראשון ובשלושה עשר'],
    houses: [1, 13],
  },
  'person.p177.relativeThirteenth': {
    aliases: ['הבית השלושה עשר היחסי', 'עולה האדם לפי עד קרוב', 'קריאה רקורסיבית בית שלושה עשר'],
    doNotMixWith: ['general.p174.h1h2h4h7h10h15'],
    houses: [1, 3, 13],
  },
  'matter.p172.h17_h1011_thenCombine': {
    aliases: ['מה תוצאת העניין', 'תוצאת עניינו של השואל', 'האם העניין טוב או רע', 'תוצאת הדבר'],
    doNotMixWith: ['completion.p173.fireRows15910'],
    houses: [1, 7, 10, 11],
  },
  'relocation.p183.h4h15': {
    aliases: ['מעבר ממקום למקום', 'איך יהיה המקום החדש', 'מה טיב המקום שאליו עוברים', 'מקום חדש', 'טיב יעד המעבר'],
    doNotMixWith: ['relocation.p183.currentVsNewPlace', 'relocation.p183.stayMoveH1H2', 'relocation.p183.compare12vs78', 'relocation.p184.multiIndicatorStayMove'],
    houses: [4, 15],
  },
  'relocation.p183.currentVsNewPlace': {
    aliases: ['האם המקום הנוכחי טוב', 'האם המעבר טוב', 'מקום נוכחי מול מקום חדש', 'השוואת מגורים ומעבר'],
    doNotMixWith: ['relocation.p183.h4h15', 'relocation.p183.stayMoveH1H2', 'relocation.p183.compare12vs78', 'relocation.p184.multiIndicatorStayMove'],
    houses: [1, 4, 7, 10],
  },
  'relocation.p183.stayMoveH1H2': {
    aliases: ['להישאר במקום או לעבור', 'האם כדאי להישאר כאן', 'האם כדאי לעבור מכאן', 'להישאר בעיר או לעזוב', 'להישאר או לעבור'],
    doNotMixWith: ['relocation.p183.h4h15', 'relocation.p183.currentVsNewPlace', 'relocation.p183.compare12vs78', 'relocation.p184.multiIndicatorStayMove'],
    houses: [1, 2],
  },
  'relocation.p183.compare12vs78': {
    aliases: ['איזו עיר עדיפה', 'איזו משתי ערים טובה יותר', 'השוואת שתי ערים', 'חוזק ראשון ושני מול שביעי ושמיני'],
    doNotMixWith: ['relocation.p183.h4h15', 'relocation.p183.currentVsNewPlace', 'relocation.p183.stayMoveH1H2', 'relocation.p184.multiIndicatorStayMove'],
    houses: [1, 2, 7, 8, 9, 15],
  },
  'relocation.p184.multiIndicatorStayMove': {
    aliases: ['סימנים נוספים לשהייה או מעבר', 'שישי שביעי ראשון שנים עשר מעבר', 'בית שני פנימי להישאר', 'דין מעבר עמ 184'],
    doNotMixWith: ['relocation.p183.h4h15', 'relocation.p183.currentVsNewPlace', 'relocation.p183.stayMoveH1H2', 'relocation.p183.compare12vs78'],
    houses: [1, 2, 6, 7, 12],
  },
  'property.p184-185.houseGardenMap': {
    aliases: ['מפת בית וגן', 'מצב הבית והגן', 'קרקע עצים צמחים תעלות חומה', 'נכסים בית וגן עמ 184', 'השביעי צמחים השלישי תעלות מים'],
    doNotMixWith: ['property.sale.unsupported', 'hidden.p188.isStillThere'],
    houses: [2, 3, 4, 7, 10],
  },
  'siblings.p182.h1h3': {
    aliases: ['יחסים בין אחים', 'הסכמה בין אחים', 'מצב האחים', 'האם האחים מסתדרים'],
    houses: [1, 3],
  },
  'travel.p238.assemble1359': {
    aliases: ['האם המסע טוב', 'האם הנסיעה מוצלחת', 'האם כדאי לצאת למסע', 'הצלחת הנסיעה', 'בטיחות והצלחת המסע'],
    houses: [1, 3, 5, 9],
  },
  'illness.bodyPart.h6Figure': {
    aliases: ['איפה בגוף החולי', 'איזה איבר חולה', 'מקום המחלה בגוף', 'איבר הגוף החולה'],
    doNotMixWith: ['illness.p196.outcomeH15'],
    houses: [6],
  },
  'hidden.p185.recursiveQuarterFireAir': {
    aliases: ['איתור רקורסיבי אש ואוויר עמ 185', '16 מקומות ארבעה חלקים 94', 'שארית ארבע מזרח מערב דרום צפון עמ 185', 'ארבעה ותשעים מקום נסתר'],
    doNotMixWith: ['hidden.p186.nameDayAbjadQuarter', 'hidden.p186.tamtamFourQuarterCasts', 'hidden.p187.kindRootDirection', 'hidden.p188.quarterDirection', 'hidden.p190-191.recursiveHouseTriangles'],
    houses: [],
  },
  'hidden.p186.nameDayAbjadQuarter': {
    aliases: ['כיוון לפי שם האם והיום', 'פנה לקיבלה שם האם יום שארית ארבע', 'אבגד גדול כיוון הדבר הנסתר', 'שם שואל שם אמו והיום עמ 186'],
    doNotMixWith: ['hidden.p185.recursiveQuarterFireAir', 'hidden.p186.tamtamFourQuarterCasts', 'hidden.p187.kindRootDirection', 'hidden.p188.quarterDirection'],
    houses: [],
  },
  'hidden.p186.tamtamFourQuarterCasts': {
    aliases: ['טמטם ארבעה רבעים עמ 186', 'שתי צורות ביניים שני מיטיבים שני מזיקים', 'ארבע הטלות כיוון טמטם', 'שלושה רבעים ריקים אחד פנימי מיטיב'],
    doNotMixWith: ['hidden.p185.recursiveQuarterFireAir', 'hidden.p186.nameDayAbjadQuarter', 'hidden.p187.kindRootDirection', 'hidden.p188.quarterDirection'],
    houses: [],
  },
  'hidden.p187.kindRootDirection': {
    aliases: ['שתי צורות מן היתדות והשלישית משתיהן', 'מין הדבר הנסתר וכיוון השורש', 'מונשאת ناحية الجاه', 'אמהות מזרח בנות מערב מאזנים דרום'],
    doNotMixWith: ['hidden.p185.recursiveQuarterFireAir', 'hidden.p186.nameDayAbjadQuarter', 'hidden.p186.tamtamFourQuarterCasts', 'hidden.p188.quarterDirection'],
    houses: [1, 4, 7, 10],
  },
  'hidden.p188.isStillThere': {
    aliases: ['האם הדבר הנסתר עדיין שם', 'האם המטמון במקומו', 'האם החפץ המוסתר עדיין במקום', 'דבר נסתר במקומו'],
    doNotMixWith: ['hidden.p188.quarterDirection', 'hiddenDepth.p188-189.openElementLengths', 'waterDepth.p189-190.tamtamTable'],
    houses: [1, 2, 4, 13, 14, 15],
  },
  'hidden.p188.quarterDirection': {
    aliases: ['ארבעה רבעים כיוון הדבר הנסתר עמ 188', 'צורה לכל כיוון פנימית מיטיבה', 'לאיזה כיוון לחפור ארבע הטלות', 'כיוון חיפוש ארבע צורות'],
    doNotMixWith: ['hidden.p185.recursiveQuarterFireAir', 'hidden.p186.nameDayAbjadQuarter', 'hidden.p186.tamtamFourQuarterCasts', 'hidden.p187.kindRootDirection', 'hidden.p190.nearFarElementDirection', 'hidden.p190-191.recursiveHouseTriangles'],
    houses: [],
  },
  'hiddenDepth.p188-189.openElementLengths': {
    aliases: ['עומק לפי יסודות פתוחים', 'אש אצבע אוויר שעל מים אמה עפר קומה', 'שתי אצבעות ושעל אחד', 'עומק דבר נסתר עמ 188 189'],
    doNotMixWith: ['waterDepth.p189-190.tamtamTable', 'well.p188.recast1468', 'hidden.p188.quarterDirection'],
    houses: [],
  },
  'waterDepth.p189-190.tamtamTable': {
    aliases: ['טמטם עומק מים', 'H1 H12 H12 H9 עומק מים', 'טבלת עומק המים עמ 189 190', 'צורה שלישית משתי תוצאות עומק'],
    doNotMixWith: ['hiddenDepth.p188-189.openElementLengths', 'well.p188.recast1468'],
    houses: [1, 9, 12],
  },
  'hidden.p190.nearFarElementDirection': {
    aliases: ['ירח מאדים קרוב שבתאי דרך קוצנית', 'קרוב או רחוק הדבר הנסתר', 'אוויר צפון אש מזרח עפר קיבלה מים מערב', 'כיוון לפי יסוד בית ראשון עמ 190'],
    doNotMixWith: ['hidden.p188.quarterDirection', 'hidden.p190-191.recursiveHouseTriangles', 'hiddenDepth.p188-189.openElementLengths'],
    houses: [1],
  },
  'hidden.p190-191.recursiveHouseTriangles': {
    aliases: ['مثلثة ארבעה כיוונים בתוך הבית', 'צמצום רקורסיבי בתוך הבית עמ 190 191', 'צורות ריקות מלאות לחלק שוב לארבעה', 'מיקום מדויק مثلثة'],
    doNotMixWith: ['hidden.p185.recursiveQuarterFireAir', 'hidden.p186.tamtamFourQuarterCasts', 'hidden.p188.quarterDirection', 'hidden.p190.nearFarElementDirection'],
    houses: [],
  },
  'well.p188.recast1468': {
    aliases: ['האם קידוח הבאר ישיג את המבוקש', 'באר H1 H4 H6 H8 אמהות', 'חפירת בארות ותעלות עמ 188', 'רביעי ויתדות מיטיבים פנימיים'],
    doNotMixWith: ['hiddenDepth.p188-189.openElementLengths', 'waterDepth.p189-190.tamtamTable'],
    houses: [1, 4, 6, 8],
  },
  'lostItem.p202.returnH6H8': {
    aliases: ['האם האבדה תחזור', 'האם החפץ האבוד ישוב', 'האם אמצא את האבדה', 'שיבת האבדה', 'חיה אבודה תחזור'],
    houses: [6, 8],
  },
  'marriage.p204.dowryH8': {
    aliases: ['מה גודל המוהר', 'האם המוהר גדול', 'גובה המוהר', 'מוהר בנישואין'],
    doNotMixWith: ['marriage.p204.previousStatusH7inH10', 'love.p204.attentionFireRows1713'],
    houses: [8],
  },
  'marriage.p204.previousStatusH7inH10': {
    aliases: ['בתולה או גרושה', 'האם היא גרושה', 'האם היא בתולה', 'מצב קודם של האישה'],
    doNotMixWith: ['marriage.p204.dowryH8', 'love.p204.attentionFireRows1713'],
    houses: [7, 10],
  },
  'love.p204.attentionFireRows1713': {
    aliases: ['האם הוא מביט אלי', 'האם היא מביטה אלי', 'אל מי מופנה המבט', 'מביטים זה בזה', 'תשומת לב באהבה'],
    doNotMixWith: ['marriage.p204.dowryH8', 'marriage.p204.previousStatusH7inH10'],
    houses: [1, 7, 13],
  },
  'authority.p256.honorConditionH10Planet': {
    aliases: ['מה מצב הכבוד והמעמד', 'כבוד ושררה', 'מעמד אצל השלטון', 'מצב המשרה והכבוד'],
    doNotMixWith: ['authority.p257.appointmentH1H10Planet', 'authority.p257.rulerConditionH7H10'],
    houses: [10],
  },
  'authority.p257.appointmentH1H10Planet': {
    aliases: ['האם יקבל משרה', 'האם יתמנה לתפקיד', 'קבלת תפקיד', 'מינוי למשרה'],
    doNotMixWith: ['authority.p256.honorConditionH10Planet', 'authority.p257.rulerConditionH7H10'],
    houses: [1, 10],
  },
  'authority.p257.rulerConditionH7H10': {
    aliases: ['מה מצב השליט', 'מצב בעל השררה', 'טובת השליט או רעתו', 'דין המושל'],
    doNotMixWith: ['authority.p256.honorConditionH10Planet', 'authority.p257.appointmentH1H10Planet'],
    houses: [7, 10],
  },
  'profession.p254.h9Planet': {
    aliases: ['מה המקצוע שלו', 'איזו מלאכה מתאימה', 'מקצוע ומלאכה', 'עיסוק לפי בית תשיעי'],
    houses: [9, 10, 11],
  },
  'theft.p224.relationshipH7Recurrence': {
    aliases: ['מה הקשר של הגנב', 'האם הגנב קרוב', 'קשר הגנב לבעל הדבר', 'קרבת הגנב'],
    doNotMixWith: ['theft.p225.thiefDescriptionH7'],
    houses: [7],
  },
  'theft.p224.recoveryH8': {
    aliases: ['האם הרכוש שנגנב יושג', 'השבת גניבה', 'האם אקבל את הגניבה בחזרה', 'דין בית שמיני בגניבה'],
    doNotMixWith: ['lostItem.p202.returnH6H8', 'theft.p224.relationshipH7Recurrence', 'theft.p225.thiefDescriptionH7'],
    houses: [8],
  },
  'enemy.p271.h1vsH12': {
    aliases: ['האם יש אויב', 'האם השואל יגבר על האויב', 'בדיקת אויב לפי בית 12'],
    doNotMixWith: ['theft.p224.relationshipH7Recurrence', 'spiritual.p167.hiddenActionAirRows46815'],
    houses: [1, 12],
  },
  'illness.p197.h1h8ElementHumor': {
    aliases: ['סוג חולי לפי היסודות', 'קור ולחות', 'מרה שחורה', 'מרה צהובה', 'רוחות שונות'],
    doNotMixWith: ['illness.p196.outcomeH15', 'illness.bodyPart.h6Figure'],
    houses: [1, 8],
  },
  'theft.p225.thiefDescriptionH7': {
    aliases: ['תיאור הגנב', 'איך הגנב נראה', 'מראה הגנב', 'פרופיל הגנב'],
    doNotMixWith: ['theft.p224.relationshipH7Recurrence'],
    houses: [7],
  },
  'religion.p253.h3h9Quality': {
    aliases: ['מה מצב דתו', 'האם הוא בעל דת', 'יראת אלוהים', 'צדקות ודת', 'מצב האמונה והדת'],
    houses: [3, 9],
  },
  'dispute.p212.reconciliationH1H7': {
    aliases: ['האם יהיה פיוס', 'האם הצדדים יתפייסו', 'פשרה בין הצדדים', 'שלום אחרי סכסוך', 'גישור ופיוס'],
    houses: [1, 7],
  },
  'desire.p206.querentWantsH7H11ThenH5': {
    aliases: ['האם השואל רוצה בדבר', 'האם אני רוצה בזה', 'רצון השואל בדבר', 'האם הוא רוצה בעניין'],
    doNotMixWith: ['love.p206.womanFavorH7H11ThenH5'],
    houses: [7, 11, 5],
  },
  'love.p206.womanFavorH7H11ThenH5': {
    aliases: ['האם האישה תמצא חן בעיניו', 'האם היא תמצא חן בעיניו', 'האם האישה מוצאת חן בעיני האיש', 'האם היא מוצאת חן בעיניי'],
    doNotMixWith: ['desire.p206.querentWantsH7H11ThenH5', 'love.p204.attentionFireRows1713'],
    houses: [7, 11, 5],
  },
  'money.p179.sourceByIncomingHonorHouse': {
    aliases: ['מאיפה יגיע הכסף', 'מה מקור הכסף', 'מאיזה מקום יבוא הכסף', 'מאיזה ערוץ יגיע הממון', 'מקור הממון'],
    doNotMixWith: ['money.p180.livelihoodH10Invert', 'money.p181.recast25811', 'inheritance.p180.elementComposite'],
    houses: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
  },
  'spiritual.p167.hiddenActionAirRows46815': {
    aliases: ['האם יש פעולה מאחורי השואל', 'האם יש פעולה מאחוריי', 'פעולה נסתרת מאחורי השואל', 'האם יש פעולה סמויה מאחוריי'],
    // The printed wording is personal (هل ورائي عمل). These older broad
    // paraphrases must not silently select p167 from free text.
    excludedPhrases: ['מאחורי הדבר', 'מאחורי העניין', 'מאחורי המצב'],
    doNotMixWith: ['spiritual.affectedBySorcery.unsupported', 'spiritual.sorcererIdentity.unsupported', 'spiritual.jinnType.unsupported'],
    houses: [4, 6, 8, 15],
  },
  'clothing.p264-265.luck': {
    aliases: ['מה מזלי בלבוש', 'האם יש מזל בבגדים', 'מזל בלבושים', 'מזל בבגד', 'לבוש מלכים'],
    doNotMixWith: ['clothing.color', 'clothing.fixedMutable'],
    houses: [5, 10, 11],
  },
});

function uniq(values) {
  return [...new Set(values.filter((value) => value !== null && value !== undefined && value !== ''))];
}

export function normalizeKashfRetrievalText(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .replace(HEBREW_DIACRITICS_RE, '')
    .replace(PUNCT_RE, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

export function tokenizeKashfRetrievalText(value) {
  return uniq(
    normalizeKashfRetrievalText(value)
      .split(' ')
      .map((token) => token.trim())
      .filter((token) => token.length > 1 && !STOPWORDS.has(token))
  );
}

function getQuestionRoutesForMethod(methodId) {
  return Object.values(KASHF_QUESTION_ROUTES).filter((route) => route.kashfMethodId === methodId);
}

function buildRecord(methodId, knowledge) {
  const method = KASHF_CANONICAL_METHODS[methodId] || null;
  if (!method || !knowledge) return null;

  const routes = getQuestionRoutesForMethod(methodId);
  const override = RETRIEVAL_OVERRIDES[methodId] || {};
  const v57 = knowledge.v57 || {};
  const pages = uniq([...(method.sourcePages || []), v57.page, ...(v57.detailPages || [])]).sort((a, b) => a - b);
  const supportingPages = uniq([...(v57.supportingPages || [])]).sort((a, b) => a - b);
  const aliases = uniq([...(override.aliases || [])]);
  const questionIds = uniq(routes.map((route) => route.questionId));
  const routeDispositions = uniq(routes.map((route) => route.disposition));
  const routeAliases = uniq(routes.map((route) => route.aliasOf));

  const searchableParts = [
    methodId,
    method.kashfIntentId,
    method.topicId,
    v57.topic,
    v57.heading,
    v57.hebrewRule,
    ...aliases,
    ...questionIds,
    ...routeAliases,
    ...pages.map(String),
  ];

  return Object.freeze({
    kashfMethodId: methodId,
    kashfIntentId: method.kashfIntentId,
    topicId: method.topicId,
    methodRole: method.methodRole,
    kashfRuntimeStatus: method.kashfRuntimeStatus,
    runtimeAllowed: method.runtimeAllowed === true,
    executorStatus: method.executorStatus,
    executionKind: method.executionKind,
    sourceConfidence: method.sourceConfidence,
    questionIds: Object.freeze(questionIds),
    routeAliases: Object.freeze(routeAliases),
    routeDispositions: Object.freeze(routeDispositions),
    aliases: Object.freeze(aliases),
    excludedPhrases: Object.freeze([...(override.excludedPhrases || [])]),
    houses: Object.freeze([...(override.houses || [])]),
    doNotMixWith: Object.freeze([...(override.doNotMixWith || [])]),
    pages: Object.freeze(pages),
    supportingPages: Object.freeze(supportingPages),
    v57: Object.freeze({
      version: v57.version,
      indexFile: v57.indexFile,
      draftFile: v57.draftFile,
      page: v57.page,
      anchor: v57.anchor,
      topic: v57.topic,
      heading: v57.heading,
      hebrewRule: v57.hebrewRule,
    }),
    operationalLanguage: knowledge.knowledgeLanguage,
    operationalRole: knowledge.knowledgeRole,
    arabicVerificationRole: knowledge.arabicVerification?.role || null,
    arabicVerificationPages: Object.freeze([...(knowledge.arabicVerification?.pages || [])]),
    notes: knowledge.notes || method.notes || null,
    searchText: normalizeKashfRetrievalText(searchableParts.join(' ')),
    searchTokens: Object.freeze(tokenizeKashfRetrievalText(searchableParts.join(' '))),
  });
}

export const KASHF_AI_RETRIEVAL_INDEX = Object.freeze(
  Object.fromEntries(
    Object.entries(KASHF_V57_KNOWLEDGE)
      .map(([methodId, knowledge]) => [methodId, buildRecord(methodId, knowledge)])
      .filter(([, record]) => Boolean(record))
  )
);

export function getKashfAiRetrievalRecord(methodId) {
  return KASHF_AI_RETRIEVAL_INDEX[methodId] || null;
}

function scoreRecord(record, query, queryTokens) {
  const normalizedQuery = normalizeKashfRetrievalText(query);
  let score = 0;
  const reasons = [];

  if (!normalizedQuery) return { score: 0, reasons };

  const excludedPhrase = (record.excludedPhrases || [])
    .map(normalizeKashfRetrievalText)
    .find((phrase) => phrase && normalizedQuery.includes(phrase));
  if (excludedPhrase) {
    return { score: 0, reasons: [`excluded-phrase:${excludedPhrase}`] };
  }

  if (normalizeKashfRetrievalText(record.kashfMethodId) === normalizedQuery) {
    score += 200;
    reasons.push('exact-method-id');
  }
  if (normalizeKashfRetrievalText(record.kashfIntentId) === normalizedQuery) {
    score += 180;
    reasons.push('exact-intent-id');
  }
  if (record.questionIds.some((id) => normalizeKashfRetrievalText(id) === normalizedQuery)) {
    score += 170;
    reasons.push('exact-question-id');
  }

  for (const alias of record.aliases) {
    const normalizedAlias = normalizeKashfRetrievalText(alias);
    if (normalizedAlias === normalizedQuery) {
      score += 150;
      reasons.push(`exact-alias:${alias}`);
    } else if (normalizedQuery.includes(normalizedAlias) || normalizedAlias.includes(normalizedQuery)) {
      score += 80;
      reasons.push(`alias-phrase:${alias}`);
    }
  }

  const aliasTokens = new Set(tokenizeKashfRetrievalText(record.aliases.join(' ')));
  const headingTokens = new Set(tokenizeKashfRetrievalText(`${record.v57.topic} ${record.v57.heading}`));
  const ruleTokens = new Set(tokenizeKashfRetrievalText(record.v57.hebrewRule));

  let aliasOverlap = 0;
  let headingOverlap = 0;
  let ruleOverlap = 0;
  for (const token of queryTokens) {
    if (aliasTokens.has(token)) aliasOverlap += 1;
    if (headingTokens.has(token)) headingOverlap += 1;
    if (ruleTokens.has(token)) ruleOverlap += 1;
  }
  if (aliasOverlap) {
    score += aliasOverlap * 24;
    reasons.push(`alias-token-overlap:${aliasOverlap}`);
  }
  if (headingOverlap) {
    score += headingOverlap * 12;
    reasons.push(`heading-token-overlap:${headingOverlap}`);
  }
  if (ruleOverlap) {
    score += ruleOverlap * 5;
    reasons.push(`rule-token-overlap:${ruleOverlap}`);
  }

  const numericTokens = queryTokens.filter((token) => /^\d+$/.test(token));
  for (const token of numericTokens) {
    if (record.pages.includes(Number(token))) {
      score += 35;
      reasons.push(`page:${token}`);
    }
  }

  // Small ranking preference only. It NEVER authorizes execution.
  if (record.runtimeAllowed && record.executorStatus === 'ready') score += 3;

  return { score, reasons };
}

export function searchKashfAiRetrievalIndex(query, options = {}) {
  const {
    limit = 8,
    sourceReadyOnly = false,
    runnableOnly = false,
    includeStatuses = null,
  } = options;

  const queryTokens = tokenizeKashfRetrievalText(query);
  const records = Object.values(KASHF_AI_RETRIEVAL_INDEX).filter((record) => {
    if (sourceReadyOnly && record.kashfRuntimeStatus !== 'ready') return false;
    if (runnableOnly && !(record.runtimeAllowed && record.executorStatus === 'ready')) return false;
    if (Array.isArray(includeStatuses) && includeStatuses.length > 0 && !includeStatuses.includes(record.kashfRuntimeStatus)) return false;
    return true;
  });

  return records
    .map((record) => {
      const scored = scoreRecord(record, query, queryTokens);
      return Object.freeze({ ...record, retrievalScore: scored.score, retrievalReasons: Object.freeze(scored.reasons) });
    })
    .filter((record) => record.retrievalScore > 0)
    .sort((a, b) => b.retrievalScore - a.retrievalScore || a.kashfMethodId.localeCompare(b.kashfMethodId))
    .slice(0, Math.max(1, Number(limit) || 8));
}

export function resolveBestKashfAiRetrievalHit(query, options = {}) {
  const [best = null, second = null] = searchKashfAiRetrievalIndex(query, { ...options, limit: 2 });
  if (!best) return Object.freeze({ resolved: false, reason: 'no-match', best: null, alternatives: Object.freeze([]) });

  // Exact identifiers/aliases can resolve directly. Otherwise require a useful
  // margin so ambiguous natural language does not silently choose a method.
  const hasExactReason = best.retrievalReasons.some((reason) => reason.startsWith('exact-'));
  const margin = second ? best.retrievalScore - second.retrievalScore : best.retrievalScore;
  const singleTokenNaturalQuery = !hasExactReason && tokenizeKashfRetrievalText(query).length <= 1 && Boolean(second);
  const resolved = hasExactReason || (!singleTokenNaturalQuery && best.retrievalScore >= 45 && margin >= 12);

  return Object.freeze({
    resolved,
    reason: resolved ? 'ranked-match' : 'ambiguous-match',
    best,
    alternatives: Object.freeze(second ? [second] : []),
    scoreMargin: margin,
  });
}

export function validateKashfAiRetrievalIndex() {
  const errors = [];
  const warnings = [];
  const records = Object.values(KASHF_AI_RETRIEVAL_INDEX);

  const sourceReadyMethods = Object.values(KASHF_CANONICAL_METHODS).filter(
    (method) => method.methodRole === 'canonical-operational' && method.kashfRuntimeStatus === 'ready'
  );
  const runnableMethods = sourceReadyMethods.filter(
    (method) => method.runtimeAllowed === true && method.executorStatus === 'ready'
  );

  for (const method of sourceReadyMethods) {
    const record = KASHF_AI_RETRIEVAL_INDEX[method.kashfMethodId];
    if (!record) {
      errors.push(`${method.kashfMethodId}: source-ready method missing AI retrieval record`);
      continue;
    }
    if (record.operationalLanguage !== 'he') errors.push(`${method.kashfMethodId}: operational language must be he`);
    if (record.operationalRole !== 'operational-primary') errors.push(`${method.kashfMethodId}: v57 must be operational-primary`);
    if (record.arabicVerificationRole !== 'verification-only') errors.push(`${method.kashfMethodId}: Arabic must be verification-only`);
    if (record.v57.indexFile !== 'kashf-v57-topic-index.html') errors.push(`${method.kashfMethodId}: wrong topic index file`);
    if (record.v57.draftFile !== 'kashf-v57-draft.html') errors.push(`${method.kashfMethodId}: wrong v57 draft file`);
    if (!record.v57.anchor || !record.pages.length) errors.push(`${method.kashfMethodId}: missing page/anchor traceability`);
  }

  for (const route of Object.values(KASHF_QUESTION_ROUTES)) {
    const record = KASHF_AI_RETRIEVAL_INDEX[route.kashfMethodId];
    if (!record) continue; // unsupported/external routes may intentionally have no v57 record
    if (!record.questionIds.includes(route.questionId)) {
      errors.push(`${route.questionId}: route is not linked into retrieval record ${route.kashfMethodId}`);
    }
  }

  for (const record of records) {
    if (!record.aliases.length && record.runtimeAllowed && record.executorStatus === 'ready') {
      warnings.push(`${record.kashfMethodId}: runnable method has no curated natural-language aliases yet`);
    }
  }

  return Object.freeze({
    valid: errors.length === 0,
    errors: Object.freeze(errors),
    warnings: Object.freeze(warnings),
    recordCount: records.length,
    sourceReadyCount: sourceReadyMethods.length,
    runnableCount: runnableMethods.length,
    sourceReadyCoveredCount: sourceReadyMethods.filter((method) => Boolean(KASHF_AI_RETRIEVAL_INDEX[method.kashfMethodId])).length,
    runnableCoveredCount: runnableMethods.filter((method) => Boolean(KASHF_AI_RETRIEVAL_INDEX[method.kashfMethodId])).length,
  });
}

export default {
  KASHF_AI_RETRIEVAL_INDEX,
  normalizeKashfRetrievalText,
  tokenizeKashfRetrievalText,
  getKashfAiRetrievalRecord,
  searchKashfAiRetrievalIndex,
  resolveBestKashfAiRetrievalHit,
  validateKashfAiRetrievalIndex,
};
