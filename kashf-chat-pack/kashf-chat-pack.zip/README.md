# חבילת כשף נקייה ל־ChatGPT

החבילה מיוצרת מן הענף המאומת של היכל החכמה. היא מיועדת לפרויקט ChatGPT נפרד העוסק בכשף, עם מסלול רוחני משלים המיוחס בנפרד לאל־קול אל־ג׳אמיע. `PROJECT_INSTRUCTIONS.md` מגדיר בן־שיח מקצועי לאורן משה, יועץ רוחני העובד עם לקוחות, עם אבחון יועץ נפרד מנוסח לקוח ותהליך לבדיקת תיקונים בשיחה. לא מעלים אל הפרויקט את כל הריפו, את ספר חאוי או נתוני לקוחות.

## קבצים להעלאה לפרויקט

הגדרה מדויקת של שם הפרויקט, קובצי ההעלאה ושיחת הבדיקה נמצאת ב־`PROJECT_SETUP.md`.

חלצו את `kashf-chat-pack.zip`. הגדירו את `PROJECT_INSTRUCTIONS.md` כהוראות הפרויקט, והעלו כקובצי ידע את `CANONICAL_METHODS.json`, `QUESTION_ROUTES.json`, `SOURCE_INDEX.json`, `QAWL_SPIRITUAL_METHOD.json`, `SPIRITUAL_SCOPE.md` ו־`PROJECT_WORKFLOWS.md`. מסלולי השאלות כוללים כעת את שמות השאלות ותיאורן בעברית כדי לאפשר שיחה טבעית ומדויקת. `SPIRITUAL_SCOPE.md` מגדיר במפורש מה הספר אומר על כישוף, פעולה נסתרת, קנאה וג׳ין, ומה אינו אבחון פעיל. `SOURCE_INDEX.json` הוא מפת עזר וגבולות מקור; הוא אינו מתיר להפעיל שיטה. אפשר להעלות גם את `GOLDEN_CASES.json` לבדיקת דוגמאות.

לשם חישוב מדויק מארבע אמהות, סביבת הפרויקט צריכה להריץ Node.js עם הקבצים שחולצו. פקודת ההרצה:

```bash
node SELF_TEST.mjs
node run.mjs '{"mothers":["2111","1111","1111","1111"],"questionId":"q-pregnancy"}'
```

בפרויקט ChatGPT יש לשמור את קובצי הידע כמקורות לפרויקט ולהשתמש בשיחת **Work עם גישת shell לקבצים שחולצו** לצורך חישוב. לפני המקרה הראשון יש להריץ את `SELF_TEST.mjs` באותה סביבת עבודה ולראות `SELF_TEST PASS`. העלאת ה־ZIP כמקור ידע לבדה אינה מפעילה את `run.mjs`, והוראות הפרויקט אינן מעניקות לצ׳אט גישה מובטחת ל־Node. יש לבדוק יכולת זו בפרויקט האמיתי. דוגמת אל־קול ב־`SELF_TEST.mjs` היא לוח בנוי המאמת את חישוב 7×7 לפי עמ׳ 36 ו־58; הספר אינו מציג שם דוגמת לוח מחושבת ל־7×7.

אפשר גם לבחור `methodId` מפורש עבור שיטה פעילה שאין לה Question ID. לשאלות הרוחניות מן המקור המשלים השתמשו ב־`q-sorcery`, `q-sorcery-h10` או `q-jinn-type`; אפשר למסור `gender:"אישה"` רק עבור תנאי המקור של כלל אם סביאן. התוצאה מחזירה עדויות מקור נפרדות ללא פסק כולל או טיוטת לקוח מוכנה. לא בוחרים שיטה לפי דמיון שמות או לפי נושא כללי. `run.mjs` מחזיר לוח ושער בטיחות; במסלול כשף הוא מחזיר פסק ומקור עברי, ובמסלול אל־קול עדויות מקור נפרדות. אין לנסח פסק ללקוח כשהריצה חסומה; במסלול כשף נדרש גם `safety.clientFacingCertified:true` וגם `clientAnswerDraft` מפורש. במסלול אל־קול אפשר לנסח רק את תוצאת הכלל המפורש בהקשרה, לפי ההוראות, בלי פסק כולל מומצא.

ארבע שיטות דורשות קלט ייעודי בנוסף ללוח: `methodInputs.candidate` יחד עם `castConfirmedOnName:true` לנישואין בעמ׳ 205/208; `methodInputs.motherCastPeriod` (`"יום"`/`"לילה"`) לשאלת האם בעמ׳ 257; או `methodInputs.quarterPatterns` (ארבע צורות מהטלות נפרדות) לכיוון חפירה בעמ׳ 188. אין להסיק את הקלטים האלה מן האמהות. למשל: `node run.mjs '{"mothers":["1111","1111","1111","1111"],"questionId":"q-mother","methodInputs":{"motherCastPeriod":"לילה"}}'`. אין לשמור פרטי אדם בקובצי הידע או בדוגמאות קבועות.

אם סביבת ChatGPT אינה מאפשרת הרצת Node.js על קובצי החבילה, החבילה משמשת לעיון, לימוד ובחירת מסלול בלבד. היא אינה הוכחה לחישוב עצמאי של 90 השיטות הפעילות בידי המודל. בדיקת GPT חי נפרדת מן הבדיקות המקומיות.

`runtime/` שבתוך ה־ZIP הוא תלות ביצוע סגורה שהועתקה מן הקוד המאומת. חלק מן הקבצים בו הם תלות טכנית ישנה של המנוע; אין להעלות אותם כקובצי ידע ואין ללמוד מהם פסקי כשף. מקור הידע התפעולי של כשף בחבילה הוא הכלל העברי של v57 ב־`CANONICAL_METHODS.json`; המקור העצמאי המשלים לבדיקות הרוחניות הוא `QAWL_SPIRITUAL_METHOD.json`. הפלט `authoritativeEngineText` מיועד ליועץ ועלול להכיל קודים והפניות לעמודים. `clientAnswerDraft` מופיע רק כאשר השיטה מאושרת וקיים בענף שנבחר `clientSafeHebrew` ייעודי שעובר את שער הניקיון. אישור מדיניות של 87 שיטות אינו מבטיח נוסח לקוח לכל ענף; כאשר הטיוטה `null`, החבילה מיועדת לאבחון היועץ בלבד באותו ענף. אין להעתיק את `authoritativeEngineText` ללקוח.

## הפקה מחדש

מן השורש של הריפו: `node kashf-chat-pack/build.mjs` ואז `node kashf-chat-pack/verify.mjs`. הסקריפט מאמת 275 רשומות מקור, 93 תיקוני v57, 47 תיקוני downstream, 48 פריטי Source Freeze, 158 שאלות ו־90 שיטות רצות (87 מהן מאושרות לפלט לקוח); הוא עוצר אם מקור עברי או תלות ביצוע חסרים. הפלט הוא `kashf-chat-pack/kashf-chat-pack.zip`.

אין לטעון שפרויקט ChatGPT הוגדר או נבדק חי רק מפני שה־ZIP נוצר. כל עדכון במקור, במיפוי או במנוע מחייב הפקה ובדיקה מחדש.
For a reproducible coverage sample, run `node kashf-chat-pack/audit-client-drafts.mjs`
after `build.mjs`. It evaluates 47 generated boards per method and reports
distinct observed branches with and without an explicit client draft. The
sample is a prioritization aid, not exhaustive branch coverage. Four audited
legacy formula methods may use their exact short `verdict.text` as the client
draft; every other method still requires `clientSafeHebrew` from the executor.
